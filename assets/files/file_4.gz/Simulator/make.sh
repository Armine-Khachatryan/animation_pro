#!/usr/bin/env bash
rm -rf ./a.out
gcc -c -Wall -Werror -g coreObj/object.c coreObj/serviceObject.c
g++ -Wall -std=c++14 -Werror -pthread -g util.cpp coreObj/objService.cpp object.o serviceObject.o coreObj/algorithmObj.cpp coreObj/comparator.cpp service/att.cpp assistant.cpp simulator.cpp main.cpp
rm -rf *.o