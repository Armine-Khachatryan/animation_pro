//
// Created by Tongxuan on 2019-05-21.
//

#include <chrono>
#include <sstream>
#include <array>
#include <cstring>
#include <unistd.h>
#include <memory>
#include "util.h"
#include "assistant.h"

void print(const string &str) {
    cout << str << endl;
}

void print(const char *c) {
    cout << c << endl;
}

void print(int i) {
    cout << i << endl;
}

void print(unsigned int i) {
    cout << i << endl;
}

void print(long long int i) {
    cout << i << endl;
}

void print(size_t s) {
    cout << s << endl;
}

void print(double d) {
    cout << d << endl;
}

void print(bool b) {
    cout << (b ? "True" : "False") << endl;
}

void print(vector<vector<string> > *v) {
    for (auto iter = v->begin(); iter != v->end(); iter++) {
        string rtn = "";
        for (auto iter2 = iter->begin(); iter2 != iter->end(); iter2++) rtn += *iter2 + " ";
        ::print(rtn);
    }
}

void print() {
    cout << endl;
}

string charToStr(const char *c) {
    if (c == nullptr) return "";
    string s(c);
    return s;
}

const char * strToChar(const string &str) {
    return str.c_str();
}

string getCurrTime(const char *syntax) {
    time_t t = time(nullptr);
    char ch[64] = {0};
    strftime(ch, sizeof(ch) - 1, syntax, localtime(&t));
    return ch;
}

string toUpper(string s) {
    int diff = 'a' - 'A';
    for (unsigned int i = 0; i < s.length(); i++) if (s[i] >= 'a' && s[i] <= 'z') s[i] -= diff;
    return s;
}

long long int getUnixTime() {
    long long int rtn = chrono::system_clock::now().time_since_epoch().count();
    //::print(rtn / 1000000000);
    //::print(rtn);
    if (rtn / 1000000000000000000 != 0) return rtn / 1000;
    return rtn;
}

unsigned int getNanoLastFourHex() {
    return getUnixTime() % 0xFFFF;
}

string convIntToHexStr(int i = 0) {
    stringstream stream;
    stream << hex << i;
    return stream.str();
}

int *merge(const int *ori, unsigned int length, const int *l, unsigned int lStart, unsigned int lEnd, const int *r,
              unsigned int rStart, unsigned int rEnd) {
    int *rtn = new int[length];
    unsigned int l_ptr = lStart;
    unsigned int r_ptr = rStart;
    unsigned int rtn_ptr = lStart;

    while (l_ptr <= lEnd && r_ptr <= rEnd && rtn_ptr <= rEnd) {
        if (ori[l[l_ptr]] <= ori[r[r_ptr]]) {
            rtn[rtn_ptr] = l[l_ptr];
            l_ptr++;
        } else {
            rtn[rtn_ptr] = r[r_ptr];
            r_ptr++;
        }
        rtn_ptr++;
    }

    for (unsigned int i = l_ptr; i <= lEnd; i++) {
        rtn[rtn_ptr] = l[i];
        rtn_ptr++;
    }

    for (unsigned int i = r_ptr; i <= rEnd; i++) {
        rtn[rtn_ptr] = r[i];
        rtn_ptr++;
    }
    return rtn;
}

int *sortCore(int *i, unsigned int length, unsigned int start, unsigned int end) {
    if (end > length || start > end) return nullptr;
    int *rtn;
    if (start == end) {
        rtn = new int[length];
        rtn[start] = start;
        return rtn;
    }

    int *leftS = sortCore(i, length, start, (start + end) / 2);
    int *rightS = sortCore(i, length, (start + end) / 2 + 1, end);

    rtn = merge(i, length, leftS, start, (start + end) / 2, rightS, (start + end) / 2 + 1, end);
    delete[] leftS;
    delete[] rightS;
    return rtn;
}

vector<vector<string> > * loadRegAlg() {
    string dir = ".algorithm/algorithm.conf";
    string regAlg = readFile(strToChar(dir));
    vector<vector<string> > *rtn = new vector<vector<string> >();
    vector<string> sv = split(regAlg, "\n");
    for (auto iter = sv.begin(); iter != sv.end(); iter++) rtn->push_back(split(*iter, "  "));
    return rtn;
}

map<string, string> * loadAlterId() {
    map<string, string> *rtn = new map<string, string>;
    vector<vector<string> > *tmpMap = loadRegAlg();
    for (auto iter = tmpMap->begin(); iter != tmpMap->end(); iter++)
        rtn->insert(make_pair((*iter)[0], (*iter)[1]));
    delete tmpMap;
    rtn->insert(make_pair("BRUTE_FORCE", "Brute Force"));
    return rtn;
}

string runShell(const char *cmd) {
    array<char, 128> buffer;
    string result;
    unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd, "r"), pclose);

    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

string runShell(const string &cmd) {
    return runShell(cmd.c_str());
}

string runSh(string& tar) {
    string tmp = tar.substr(0, 2);
    if (tmp != "./" && tmp != "..") tar = "./" + tar;
    return runShell(tar.c_str());
}

void mkdir(const string &dir) {
    runShell("mkdir " + dir);
}

void touch(const string &tar) {
    runShell("touch " + tar);
}

void writeFile(const char *s, string tarAdd, const char *tar, const char *mod) {
    if (tarAdd[tarAdd.length() - 1] != '/') tarAdd += "/";
    if (!dirExist(tarAdd)) mkdir(tarAdd);
    FILE *f = nullptr;
    f = fopen(tar, mod);
    fputs(s, f);
    fclose(f);
    if (tarAdd != "./") {
        string cmd = "mv " + string(tar) + " " + tarAdd + string(tar);
        runShell(cmd.c_str());
    }
}

void writeFile(const string &cont, const string &tar) {
    vector<string> tarVec = split(tar, "/");
    string tarF = tarVec[tarVec.size() - 1];
    string tarA = "";
    for (unsigned int i = 0; i < tarVec.size() - 1; i++) {
        tarA += tarVec[i];
        if (i != tarVec.size() - 2) tarA += "/";
    } if (tar.size() > 0 && tar[0] == '/') tarA = "/" + tarA;
    if (!dirExist(tarA)) mkdir(tarA);
    if (!fileExist(tar)) touch(tar);
    writeFile(strToChar(cont), tarA, strToChar(tarF), strToChar("w"));
}

void updateFile(const string &cont, const string &tar) {
    writeFile(readFile(strToChar(tar)) + cont, tar);
}

bool dirExist(const string& tar) {
    return access(tar.c_str(), 0) == 0;
}

bool fileExist(const char *tar) {
    FILE *f = fopen(tar, "r");
    if (f == nullptr) return false;
    fclose(f);
    return true;
}

bool fileExist(const string &tar) {
    return fileExist(strToChar(tar));
}

string readFile(const char *tar) {
    if (!fileExist(tar)) return "";
    array<char, 128> buff;
    FILE *f = fopen(tar, "r");
    string rtn = "";
    while (fgets(buff.data(), buff.size(), f) != nullptr) {
        rtn += buff.data();
    }
    fclose(f);
    return rtn;
}

void rmFile(const char *tar) {
    runShell("rm -rf " + charToStr(tar));
}

void mv(const string &tar, const string &des) {
    runShell("mv " + tar + " " + des);
}

string genTarAlgSh(string& tarAdd, string& tarExe, string& genAdd, string& genTar, string& genExe) {
    if (tarAdd.substr(tarAdd.length() - 1, tarAdd.length()) != "/") tarAdd += "/";
    if (tarExe.substr(0, 2) != "./") tarExe = "./" + tarExe;
    if (genAdd.substr(genAdd.length() - 1, genAdd.length()) != "/") genAdd += "/";
    if (genTar.substr(0, 2) == "./") genTar = genTar.substr(2, genTar.length());

    string genExeTar = genAdd + genTar;
    string content = "#!/bin/bash\n"
                     "cd " + genAdd + tarAdd + "\n"
                     + tarExe + " ../request.conf" + "\n";
    writeFile(content.c_str(), genAdd, genTar.c_str(), "w");
    runShell(("chmod 755 " + genExeTar).c_str());
    runShell(("chmod +x " + genExeTar).c_str());
    return genExeTar;
}

string hexToStr(int i) {
    string rtn = "";
    if (i / 0xF == 0){
        char c;
        if (i >= 0 && i <= 9) c = i + 0x30;
        else if (i >= 0xA && i < 0xF) c = i + ('A' - 0xA);
        string tmp(&c);
        rtn += tmp;
        return rtn;
    } else {
        rtn = hexToStr(i / 0xF) + hexToStr(i % 0xF);
        return rtn;
    }
}

bool isValidUnNum(const string &str) {
    for (unsigned int i = 0; i < str.length(); i++)
        if (str[i] < 0x30 || str[i] > 0x39) return false;
    return true;
}

unsigned int stringToUnNum(const string tar) {
    if (!isValidUnNum(tar)) return 0;
    unsigned int rtn = 0;
    for (unsigned int i = 0; i < tar.length(); i++) {
        rtn *= 10;
        rtn = rtn + tar[i] - 0x30;
    } return rtn;
}

vector<string> split(const string &line, const string &delimiters) {
    vector<string> words;
    size_t end = 0;

    for (;;) {
        size_t start = line.find_first_not_of(delimiters, end);
        if (start == string::npos) break;
        end = line.find_first_of(delimiters, start);
        words.push_back(line.substr(start, end - start));
    }
    return words;
}

bool validate(string &n, string &r, string &e, const string &m) {
    if (r[r.length() - 1] != '/') r += "/";
    string absAdd = r + e;
    string tarAdd = ".algorithm/" + n;
    if (!fileExist(absAdd.c_str())|| (m == "a" && dirExist(tarAdd))) return false;
    return true;
}

bool contains(const string &larger, const string &sub) {
    if (larger.find(sub) != std::string::npos) return true;
    return false;
}

void deleteMap(map<string, unsigned int> *m) {
    if (m == nullptr) return;
    while (m->size() > 0) m->erase(m->begin());
    delete m;
    m = nullptr;
}

vector<string> loadReqConf() {
    return split(readFile(".algorithm/request.conf"), "\n");
}

char *constToFlex(const char *c) {
    char *rtn = (char *)calloc(1024, sizeof(char));
    strcpy(rtn, c);
    return rtn;
}

