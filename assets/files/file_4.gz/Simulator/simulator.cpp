//
// Created by Tongxuan on 2019-07-28.
//

#include "simulator.h"
#include "util.h"
#include "assistant.h"

string printList() {
    vector<vector<string> > *rtnVec = loadRegAlg();
    if (rtnVec->size() == 0) return "No record.";
    string rtn = "AID\t\t\tName\n";
    for (unsigned int i = 0; i < rtnVec->size(); i++)
        rtn += (*rtnVec)[i][0] + "\t" + (*rtnVec)[i][1] + "\n";
    return rtn += "======END OF LIST======";
}

string surprise() {
    return ""
           "#          ┏┓   ┏┓\n"
           "#      ┏━━━┛┻━━━┛┻━━━┓\n"
           "#      ┃             ┃\n"
           "#      ┃      ━      ┃\n"
           "#      ┃    ┳┛ ┗┳    ┃\n"
           "#      ┃             ┃\n"
           "#      ┃      ┻      ┃\n"
           "#      ┃             ┃\n"
           "#      ┗━━┓        ┏━┛\n"
           "#         ┃        ┃\n"
           "#         ┃        ┃\n"
           "#         ┃        ┗━━━┓\n"
           "#         ┃            ┣┓\n"
           "#         ┃            ┏┛\n"
           "#         ┗━━┓┓┏━━┳┓┏━━┛\n"
           "#            ┃┫┫  ┃┫┫\n"
           "#            ┗┻┛  ┗┻┛\n"
           "#\n"
           "#\n"
           "## So please bless me there is no bug.\n";
}

string genHelpMsg() {
    string rtn = ""
                 "This is a simulator and algorithm performance analyzer for HPC cluster.\n"
                 "You may add you special algorithm onto this simulator to simulate the cluster or to analyze your algorithm performance.\n"
                 "By default, this program comes with a brute force algorithm.\n"
                 "To add you own algorithm, we requires you to have a shell script to compile and to run your algorithm.\n"
                 "Please have the ROOT dir address of your algorithm ready.\n"
                 "Your new algorithm will be ran as an independent program.\n"
                 "Please make sure you program can read an appointed file as configuration input.\n"
                 "The syntax of the configuration file should seems like this:\n\n"
                 "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
                 "|clusterCPU clusterGPU clusterMEM                              |\n"
                 "|JID pushTime jobPriority jobCPU jobGPU jobMEM jobExeLength    |\n"
                 "|JID pushTime jobPriority jobCPU jobGPU jobMEM jobExeLength    |\n"
                 "|JID pushTime jobPriority jobCPU jobGPU jobMEM jobExeLength    |\n"
                 "|JID pushTime jobPriority jobCPU jobGPU jobMEM jobExeLength    |\n"
                 "|JID pushTime jobPriority jobCPU jobGPU jobMEM jobExeLength    |\n"
                 "| ... ... ... ... ...                                          |\n"
                 "| ... ... ... ... ...                                          |\n"
                 "| ... ... ... ... ...                                          |\n"
                 "| ... ... ... ... ...                                          |\n"
                 "|                                                              |\n"
                 "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"
                 "\n"
                 "To add new algorithm, please use:\n"
                 "\t-a | --add [yourAlgorithmName] [algorithmRootDir] [executionPath]\n"
                 "NOTICE: PLEASE MAKE SURE YOUR TARGET EXECUTION FILE IS RUNNABLE."
                 "To compare and analyze the performance of all registered algorithm, use:\n"
                 "\t-c | --compare [option (optional)] ... [option (optional)]\n"
                 "\t\tuse -d or --detail as an option flag to print service detailed inner info\n"
                 "\t\tuse -r or --rank as an option flag to print all algorithm scores and their ranking\n"
                 "\t\tuse -t or --time as an option flag to print internal processing time\n"
                 "\t\tuse -f=(fileAdd) or --file=(fileAdd) as an option flag to configure your input file\n"
                 "If you do not have a input file, we will generate a default input for you.\n"
                 "If you want to print the internal scores and system status, use -cp or --comparePrint flag.\n"
                 "To list all registered algorithms, please:\n"
                 "\t-l | --list\n"
                 "For help, use:\n"
                 "\t-h | --help\n"
                 "To update current algorithm registrations, use:\n"
                 "\t-u | --update [yourAlgorithmName] [algorithmNewRootDir] [executionNewPath]\n"
                 "To remove one registered algorithm, use:\n"
                 "\t-r | --remove [algorithNameToRm]\n"
                 "To ultimately reset the simulator to the default status, use:\n"
                 "\t--reset WARNING: DANGER ZONE!"
                 "\n"
                 "Thank you and hope you can enjoy your use~";
    return rtn;
}

string add(int argc, char **argv) {
    if (argc < 5) {
        return illegalCmd(3, "add");
    } else {
        string name(argv[2]);
        string dir(argv[3]);
        string exe(argv[4]);
        Assistant *a = new Assistant();
        a->regNewAlg(name, dir, exe);
        delete a;
        a = nullptr;
        return "Add success";
    }
}

string update(int argc, char **argv) {
    if (argc < 5) return illegalCmd(3, "update");
    string name(argv[2]);
    string root(argv[3]);
    string exe(argv[4]);
    Assistant *a = new Assistant();
    a->update(name, root, exe);
    delete a;
    a = nullptr;
    return "Update success";
}

string illegalCmd(int i, const string &func) {
    return "Illegal request. Minimum " + to_string(i) + " parameters required for " + func + ".\nUse -h for help.";
}

string remove(char *name) {
    string n(name);

    Assistant *a = new Assistant();
    a->remove(n);
    delete a;
    a = nullptr;
    return "Remove success";
}

string reset() {
    puts("\x1b[43;31mCAUTION! DANGER ZONE\x1b[0m");
    printf("Everything will be reset.\nSure to continue? (Y/n): ");
    string usr;
    cin >> usr;
    if (usr == "Y") {
        string cmd = "rm -rf .algorithm";
        runShell(cmd.c_str());
        return "Reset finished.";
    } else return "Reset cancelled";
}

string compare(unsigned int flag) {
    Assistant *a = new Assistant();
    if (!fileExist(".algorithm/request.conf")) a->genTestCase(flag);
    string rtn = a->compare(flag);
    delete a;
    return rtn;
}

void genTestCase(int argc, char **argv) {
    string str = argc >= 3 ? argv[2] : "./";
    if (fileExist(".algorithm/request.conf")) {
        runShell("cp .algorithm/request.conf " + str);
        return;
    }
    Assistant *a = new Assistant();
    a->genTestCase(0);
    runShell("mv .algorithm/request.conf " + str);
    delete a;
    a = nullptr;
}

string genEvalPY() {
    return "from openpyxl import Workbook;\n"
           "import platform, glob;\n"
           "from openpyxl import Workbook;\n"
           "from openpyxl.chart import (\n"
           "    LineChart,\n"
           "    Reference,\n"
           ");\n"
           "\n"
           "def writeXls(oriFile: str, cont: list, wb: Workbook) -> int:\n"
           "    if oriFile == \"./finT.txt\":\n"
           "        ws = wb.create_sheet(\"Fin\");\n"
           "\n"
           "    elif oriFile == \"./r.txt\":\n"
           "        ws = wb.create_sheet(\"R\");\n"
           "\n"
           "    elif oriFile == \"./util_c.txt\":\n"
           "        ws = wb.create_sheet(\"C\");\n"
           "\n"
           "    elif oriFile == \"./util_comprehensive.txt\":\n"
           "        ws = wb.create_sheet(\"Comprehensive\");\n"
           "\n"
           "    elif oriFile == \"./util_g.txt\":\n"
           "        ws = wb.create_sheet(\"G\");\n"
           "\n"
           "    elif oriFile == \"./util_m.txt\":\n"
           "        ws = wb.create_sheet(\"M\");\n"
           "\n"
           "    else:\n"
           "        print(\"File \" + oriFile + \" not expected\");\n"
           "        return 0;\n"
           "\n"
           "    cont1: list;\n"
           "    for var in cont:\n"
           "        cont1 = var.split(\"\\t\");\n"
           "        ws.append(cont1);\n"
           "\n"
           "    rtn: int = len(cont) - 2;\n"
           "    for num in range(2, rtn + 1):\n"
           "        a: str = \"A\" + str(num);\n"
           "        b: str = \"B\" + str(num);\n"
           "        c: str = \"C\" + str(num);\n"
           "        ws[a].style = 'Comma [0]';\n"
           "        ws[b].style = 'Comma [0]';\n"
           "        ws[c].style = 'Comma [0]';\n"
           "\n"
           "    ws[\"E32\"] = \"AVG\";\n"
           "    ws[\"E33\"] = \"STD\";\n"
           "    ws[\"E34\"] = \"AVG_IMP\";\n"
           "    cont1 = cont[0].split(\"\\t\");\n"
           "    ws[\"F31\"] = \"#\" + cont1[0][len(cont1[0]) - 4:];\n"
           "    ws[\"G31\"] = \"#\" + cont1[1][len(cont1[1]) - 4:];\n"
           "    ws[\"H31\"] = \"BRUTE_F\";\n"
           "\n"
           "    ws[\"F32\"] = \"=average(A2:A\" + str(rtn + 1) + \")\";\n"
           "    ws[\"G32\"] = \"=average(B2:B\" + str(rtn + 1) + \")\";\n"
           "    ws[\"H32\"] = \"=average(C2:C\" + str(rtn + 1) + \")\";\n"
           "\n"
           "    ws[\"F33\"] = \"=stdev(A2:A\" + str(rtn + 1) + \")\";\n"
           "    ws[\"G33\"] = \"=stdev(B2:B\" + str(rtn + 1) + \")\";\n"
           "    ws[\"H33\"] = \"=stdev(C2:C\" + str(rtn + 1) + \")\";\n"
           "\n"
           "    ws[\"F34\"] = \"=(F32-H32)/H32\";\n"
           "    ws[\"G34\"] = \"=(G32-H32)/H32\";\n"
           "    ws[\"H34\"] = \"=(H32-H32)/H32\";\n"
           "    ws[\"F34\"].style = 'Percent';\n"
           "    ws[\"G34\"].style = 'Percent';\n"
           "    ws[\"H34\"].style = 'Percent';\n"
           "\n"
           "    c1 = LineChart();\n"
           "    ttlTmp: str = \"\";\n"
           "    if (rtn < 1000): ttlTmp = str(rtn);\n"
           "    else: ttlTmp = str(rtn / 1000) + \"K\";\n"
           "    if oriFile == \"./finT.txt\": ttlTmp += \"FT\";\n"
           "    elif oriFile == \"./r.txt\": ttlTmp += \"RK\";\n"
           "    elif oriFile == \"./util_c.txt\": ttlTmp += \"UC\";\n"
           "    elif oriFile == \"./util_comprehensive.txt\": ttlTmp += \"CP\";\n"
           "    elif oriFile == \"./util_g.txt\":ttlTmp += \"UG\";\n"
           "    elif oriFile == \"./util_m.txt\":ttlTmp += \"UM\";\n"
           "    c1.title = ttlTmp;\n"
           "\n"
           "    ref = Reference(ws, min_col = 1, min_row=1, max_col=3, max_row=rtn + 1);\n"
           "    c1.add_data(ref, titles_from_data=True);\n"
           "    ws.add_chart(c1, \"E3\");\n"
           "\n"
           "    return rtn;\n"
           "\n"
           "\n"
           "def main():\n"
           "    if int(platform.python_version().split(\".\")[0]) <= 2:\n"
           "        print(\"This program only support python 3, please check your python runtime version and try again.\");\n"
           "        return;\n"
           "    fileList: list = glob.glob(\"./*.txt\");\n"
           "    length: int = 0;\n"
           "    if len(fileList) > 0:\n"
           "        wb: Workbook = Workbook();\n"
           "        for var in fileList:\n"
           "            f = open(var, \"r\");\n"
           "            content : str = f.read();\n"
           "            contList : list = content.split(\"\\n\");\n"
           "            tmp: int = writeXls(var, contList, wb);\n"
           "            if (tmp > length): length = tmp;\n"
           "            f.close();\n"
           "        wb.remove(wb[\"Sheet\"]);\n"
           "        wb.save(\"./\" + str(length) + \".xlsx\");\n"
           "        wb.close();\n"
           "    else:\n"
           "        print(\"No qualified file found\");\n"
           "\n"
           "\n"
           "if __name__ == \"__main__\":\n"
           "    main();";
}

