//
// Created by Tongxuan on 2019-07-28.
//

#ifndef SIMULATORC_COMPARATOR_H
#define SIMULATORC_COMPARATOR_H

#include "algorithmObj.h"
#include "../util.h"

class Comparator {
private:
    unsigned int len;
    Algorithm **a;
    map<string, Request *> *stdRM;
    map<string, string> *alterID;
    string getAlgAlterID(const char *c);
    string genRtnMsg(char *c);
public:
    Comparator(Algorithm **, unsigned int, map<string, Request *> *);
    Comparator(const Comparator &s) = delete;
    Comparator& operator=(const Comparator& s) = delete;
    Comparator(Comparator&& s) = delete;
    Comparator& operator=(Comparator&& s) = delete;
    ~Comparator();

    string doCompare(unsigned int);
    void print(Cluster *c);
};

#endif //SIMULATORC_COMPARATOR_H
