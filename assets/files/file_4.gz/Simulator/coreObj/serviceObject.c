//
// Created by Tongxuan on 2019-07-16.
//

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "serviceObject.h"

int *merge(const int *ori, int length, const int *l, int lStart, int lEnd, const int *r, int rStart, int rEnd) {
    int *rtn = calloc(length, sizeof(int));
    int l_ptr = lStart;
    int r_ptr = rStart;
    int rtn_ptr = lStart;

    while (l_ptr <= lEnd && r_ptr <= rEnd && rtn_ptr <= rEnd) {
        if (ori[l[l_ptr]] <= ori[r[r_ptr]]) {
            rtn[rtn_ptr] = l[l_ptr];
            l_ptr++;
        } else {
            rtn[rtn_ptr] = r[r_ptr];
            r_ptr++;
        }
        rtn_ptr++;
    }

    for (int i = l_ptr; i <= lEnd; i++) {
        rtn[rtn_ptr] = l[i];
        rtn_ptr++;
    }

    for (int i = r_ptr; i <= rEnd; i++) {
        rtn[rtn_ptr] = r[i];
        rtn_ptr++;
    }
    return rtn;
}

int *cSortCore(int *i, int length, int start, int end) {
    if (end > length || start > end) return NULL;
    int *rtn;
    if (start == end) {
        rtn = calloc(length, sizeof(int));
        rtn[start] = start;
        return rtn;
    }

    int *leftS = cSortCore(i, length, start, (start + end) / 2);
    int *rightS = cSortCore(i, length, (start + end) / 2 + 1, end);

    rtn = merge(i, length, leftS, start, (start + end) / 2, rightS, (start + end) / 2 + 1, end);
    free(leftS);
    free(rightS);
    return rtn;
}

Request *requestList2Arr(RequestList *rl) {
    Request *r = calloc(rl->length, sizeof(Request));
    RequestNode *n = rl->head;
    for (int i = 0; i < rl->length; i++) {
        r[i] = *(n->r);
        n = n->next;
    }
    return r;
}

RequestList *requestArr2List(Request *r, int length) {
    RequestList *l = newRequestList();
    for (int i = 0; i < length; i++) requestListInsert(l, &r[i]);
    return l;
}

Status *statusList2Arr(StatusList *sl) {
    Status *s = calloc(sl->length, sizeof(Status));
    StatusNode *n = sl->head;
    for (int i = 0; i < sl->length; i++) {
        s[i] = *(n->s);
        n = n->next;
    }
    return s;
}

StatusList *statusArr2List(Status *s, int length) {
    StatusList *l = newStatusList();
    for (int i = 0; i < length; i++) statusListInsert(l, &s[i]);
    return l;
}

MapNode *statusMap2Arr(StatusMap *sm) {
    MapNode *mn = calloc(sm->length, sizeof(MapNode));
    MapConnector *mc = sm->head;
    for (int i = 0; i < sm->length; i++) {
        mn[i] = *(mc->n);
        mc = mc->next;
    }
    return mn;
}

StatusMap *mapNodeArr2Map(MapNode *mn, int length) {
    StatusMap *m = newStatusMap();
    for (int i = 0; i < length; i++) statusMapInsert(m, &mn[i]);
    return m;
}

RequestList *cSortPublicRequest(int *i, Request *ra, int length) {
    int *temp = cSortCore(i, length, 0, length - 1);
    Request *rtnA = calloc(length, sizeof(Request));
    for (int j = 0; j < length; j++) rtnA[j] = ra[temp[j]];
    free(temp);
    RequestList *rtn = requestArr2List(rtnA, length);
    free(rtnA);
    return rtn;

}

StatusList *cSortPublicStatus(int *i, Status *rs, int length) {
    int *temp = cSortCore(i, length, 0, length - 1);
    Status *rtnA = calloc(length, sizeof(Status));
    for (int j = 0; j < length; j++) rtnA[j] = rs[temp[j]];
    free(temp);
    StatusList *rtn = statusArr2List(rtnA, length);
    free(rtnA);
    return rtn;

}

StatusMap *cSortPublicMap(int *i, MapNode *mn, int length) {
    int *temp = cSortCore(i, length, 0, length - 1);
    MapNode *rtnA = calloc(length, sizeof(MapNode));
    for (int j = 0; j < length; j++) rtnA[j] = mn[temp[j]];
    free(temp);
    StatusMap *rtn = mapNodeArr2Map(rtnA, length);
    free(rtnA);
    return rtn;
}

RequestList *cSortPrio(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].prio;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

RequestList *cSortAdjPrio(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].adjPrio;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

RequestList *cSortPu(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].pushTime;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

RequestList *cSortExeLength(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].exeLength;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

RequestList *cSortExeSeq(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].exeSeq;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

RequestList *cSortExeTimeStamp(RequestList *rl) {
    Request *ra = requestList2Arr(rl);
    int *i = calloc(rl->length, sizeof(int));
    for (int j = 0; j < rl->length; j++) i[j] = ra[j].exeTimeStamp;
    RequestList *rtn = cSortPublicRequest(i, ra, rl->length);
    free(ra);
    free(i);
    return rtn;
}

StatusList *cSortStartTime(StatusList *sl) {
    Status *sa = statusList2Arr(sl);
    int *i = calloc(sl->length, sizeof(Status));
    for (int j = 0; j < sl->length; j++) i[j] = sa[j].timeStart;
    StatusList *rtn = cSortPublicStatus(i, sa, sl->length);
    free(sa);
    free(i);
    return rtn;
}

StatusList *cSortFinTime(StatusList *sl) {
    Status *sa = statusList2Arr(sl);
    int *i = calloc(sl->length, sizeof(Status));
    for (int j = 0; j < sl->length; j++) i[j] = sa[j].timeTerminate;
    StatusList *rtn = cSortPublicStatus(i, sa, sl->length);
    free(sa);
    free(i);
    return rtn;
}

StatusMap *cSortTimeNode(StatusMap *sm) {
    MapNode *mn = statusMap2Arr(sm);
    int *i = calloc(sm->length, sizeof(MapNode));
    for (int j = 0; j < sm->length; j++) i[j] = mn[j].time;
    StatusMap *rtn = cSortPublicMap(i, mn, sm->length);
    free(mn);
    free(i);
    return rtn;
}

MapNode *getProperNode(StatusMap *sm, unsigned int time, const TF *stdTF) {
    MapNode *rtn = newMapNode(time, stdTF->len, stdTF->p);
    if (sm->length == 0) return rtn;
    MapConnector *mc = sm->tail;
    while (mc != NULL) {
        if (mc->n->time > time) for (unsigned int i = 0; i < stdTF->len; i++) rtn->t->p[i]->var = mc->n->t->p[i]->var;
        else if (mc->n->time == time) {
            deleteMapNode(rtn);
            rtn = copyMapNode(mc->n);
            break;
        } else break;
        mc = mc->prev;
    }
    return rtn;
}

bool haveSuchNode(StatusMap *sm, MapNode *mn) {
    for (MapConnector *tmp = sm->head; tmp != NULL; tmp = tmp->next) if (tmp->n->time == mn->time) return true;
    return false;
}

StatusMap *updateStatusMap(StatusMap *sm, Status *s, const TF *stdTF) {
    MapNode *mnS = getProperNode(sm, s->timeStart, stdTF);
    if (!haveSuchNode(sm, mnS)) statusMapInsert(sm, mnS);
    deleteMapNode(mnS);
    StatusMap *tmp = moveStatusMap(cSortTimeNode(sm));
    deleteStatusMap(sm);
    sm = moveStatusMap(tmp);

    MapNode *mnE = getProperNode(sm, s->timeTerminate, stdTF);
    if (!haveSuchNode(sm, mnE)) statusMapInsert(sm, mnE);
    deleteMapNode(mnE);
    tmp = moveStatusMap(cSortTimeNode(sm));
    deleteStatusMap(sm);
    sm = moveStatusMap(tmp);

    MapConnector *mc = sm->head;
    while (mc != NULL) {
        if (mc->n->time > s->timeStart && mc->n->time <= s->timeTerminate) {
            for (unsigned int i = 0; i < mc->n->t->len; i++) mc->n->t->p[i]->var += s->t->p[i]->var;
        } else if (mc->n->time > s->timeTerminate) break;
        mc = mc->next;
    }
    return sm;
}

