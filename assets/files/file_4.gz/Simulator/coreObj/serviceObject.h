//
// Created by Tongxuan on 2019-07-16.
//

#ifndef SCHEDULER_SERVICEOBJECT_H
#define SCHEDULER_SERVICEOBJECT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "object.h"

int * cSortCore(int *i, int length, int start, int end);

Request * requestList2Arr(RequestList *rl);
RequestList * requestArr2List(Request *r, int length);

Status * statusList2Arr(StatusList *sl);
StatusList * statusArr2List(Status *s, int length);

MapNode * statusMap2Arr(StatusMap *sm);
StatusMap * mapNodeArr2Map(MapNode *mn, int length);

RequestList * cSortPrio(RequestList *rl);
RequestList * cSortAdjPrio(RequestList *rl);
RequestList * cSortPu(RequestList *rl);
RequestList * cSortExeLength(RequestList *rl);
RequestList * cSortExeSeq(RequestList *rl);
RequestList * cSortExeTimeStamp(RequestList *rl);

StatusList * cSortStartTime(StatusList *sl);
StatusList * cSortFinTime(StatusList *sl);

StatusMap * cSortTimeNode(StatusMap *sm);

StatusMap * updateStatusMap(StatusMap *sm, Status *s, const TF *stdTF);

#ifdef __cplusplus
};
#endif

#endif //SCHEDULER_SERVICEOBJECT_H
