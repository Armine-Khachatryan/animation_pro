//
// Created by Tongxuan on 2019-05-22.
//

#include "../util.h"

string encryId(string str) {
    string rtn = "";
    int temp = 0;
    for (unsigned int i = 0; i < str.length(); i++) temp += str[i];
    rtn = str + convIntToHexStr(temp / 0xF) + convIntToHexStr(temp % 0xF);
    return toUpper(rtn);
}

string genID(const string code) {
    string n = convIntToHexStr(getNanoLastFourHex());
    for (unsigned int i = n.length(); i < 4; i++) n = "0" + n;
    string yearPara = "%y";
    string monPara = "%m";
    string dayPara = "%d";
    string hourPara = "%H";
    string minPara = "%M";
    string secPara = "%S";
    string rtn = getCurrTime(yearPara.c_str()) + code + toUpper(n.substr(0, 4)) + getCurrTime(monPara.c_str()) +
                 getCurrTime(dayPara.c_str()) + getCurrTime(hourPara.c_str()) + getCurrTime(minPara.c_str()) +
                 getCurrTime(secPara.c_str());
    return encryId(rtn);
}

