//
// Created by Tongxuan on 2019-07-28.
//

#ifndef SIMULATORC_ALGORITHMOBJ_H
#define SIMULATORC_ALGORITHMOBJ_H

#include "object.h"
#include "../util.h"

class Algorithm {
private:
    char * id;
    map<string, unsigned int> *rm;
    StatusMap *sm;
    bool valid;
    double score;
public:
    Algorithm(const char *id, const char *cont, map<string, Request *> *, Cluster *, TF *stdTF);
    Algorithm(const Algorithm &s);
    Algorithm& operator=(const Algorithm& s);
    Algorithm(Algorithm&& s);
    Algorithm& operator=(Algorithm&& s);
    ~Algorithm();

    void print(Cluster *c);
    char *getID() {return this->id;}
    map<string, unsigned int> *getExe() {return this->rm;}
    void scoreMod(unsigned int i) {this->score += i;}
    double getScore() {return this->score;}
    StatusMap *getSttMap() {return this->sm;}
};

#endif //SIMULATORC_ALGORITHMOBJ_H
