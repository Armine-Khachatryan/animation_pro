//
// Created by Tongxuan on 2019-07-28.
//

#include "comparator.h"

Comparator::Comparator(Algorithm **a, unsigned int len, map<string, Request *> *m) {
    this->a = a;
    this->stdRM = new map<string, Request *>;
    for (auto iter = m->begin(); iter != m->end(); iter++)
        this->stdRM->insert(make_pair(iter->first, copyRequest(iter->second)));
    this->len = len;
    this->alterID = ::loadAlterId();
}

Comparator::~Comparator() {
    this->len = 0;
    for (auto iter = this->stdRM->begin(); iter != this->stdRM->end(); iter++) deleteRequest(iter->second);
    delete this->stdRM;
    this->stdRM = nullptr;
    delete this->alterID;
    this->alterID = nullptr;
}

string Comparator::getAlgAlterID(const char *c) {
    return " (a.k.a. " + this->alterID->find(charToStr(c))->second + ")";
}

string Comparator::genRtnMsg(char *c) {
    if (c == nullptr) return "Comparator internal Error, please contact us at yibo.guo@ais.cmc.osaka-u.ac.jp";
    return "We found " + charToStr(c) + getAlgAlterID(c) + " is the best algorithm.";
}

string Comparator::doCompare(unsigned int flag) {
    string rtn = "";
    if (this->len == 0) return "No registered algorithms";

    if (this->len == 1) {
        rtn = "Only one valid algorithm " + charToStr(a[0]->getID()) +
              alterID->find(a[0]->getID())->second +
              " exists, comparator terminated.";
        delete alterID;
        return rtn;
    }

    // This for loop is evaluating the algorithm performance on each of those registered job requests
    for (auto iter = this->stdRM->begin(); iter != this->stdRM->end(); iter++) {

        int *reqExe = new int[this->len];
        for (unsigned int i = 0; i < this->len; i++)
            reqExe[i] = this->a[i]->getExe()->find(iter->first)->second;
        // find the req running ts in each alg

        // obtain algorithms in order by each request's exe timestamp
        int *reqExe1 = sortCore(reqExe, this->len, 0, this->len - 1);
        delete[] reqExe;

        for (unsigned int i = 0; i < this->len - 1; i++) {
            int count = 0;
            for (unsigned j = i + 1; j < this->len; j++)
                if (this->a[reqExe1[i]]->getExe()->find(iter->first)->second <
                    this->a[reqExe1[j]]->getExe()->find(iter->first)->second) {
                    count = this->len - j;
                    break;
                }
            this->a[reqExe1[i]]->scoreMod(count);
        } delete[] reqExe1;
    }


    // modify algorithm score by system utility
    int *utilComp = new int[this->len];
    for (unsigned int i = 0; i < this->len; i++) {
        utilComp[i] = 0;
        StatusMap *sm = copyStatusMap(this->a[i]->getSttMap());
        for (auto tmp = sm->head; tmp != nullptr; tmp = tmp->next)
            for (unsigned int j = 0; j < tmp->n->t->len; j++)
                utilComp[i] += (signed) tmp->n->t->p[j]->var;
        deleteStatusMap(sm);
    }

    int *tmpInt2 = sortCore(utilComp, this->len, 0, this->len - 1);
    for (unsigned int i = 1; i < this->len; i++) {
        int score = 0;
        for (unsigned int j = 0; j < i; j++)
            if (utilComp[tmpInt2[i]] > utilComp[tmpInt2[j]])
                score = j + 1;
        this->a[tmpInt2[i]]->scoreMod(score * 2);
    }
    delete[] utilComp;
    delete[] tmpInt2;


    // modify algorithm score by overall system running time
    int *algFinTime = new int[this->len];
    for (unsigned int i = 0; i < this->len; i++)
        algFinTime[i] = this->a[i]->getSttMap()->tail->n->time;
    int *tmpIntArr3 = sortCore(algFinTime, this->len, 0, this->len - 1);
    for (unsigned int i = 0; i < this->len - 1; i++) {
        int score = 0;
        for (unsigned int j = i + 1; j < this->len; j++)
            if (algFinTime[tmpIntArr3[i]] < algFinTime[tmpIntArr3[j]]) {
                score = this->len - j;
                break;
            }
        this->a[tmpIntArr3[i]]->scoreMod(score);
    }
    delete[] algFinTime;
    delete[] tmpIntArr3;


    // Get the final decision
    int *finalSort = new int[this->len];
    for (unsigned int i = 0; i < this->len; i++)
        finalSort[i] = this->a[i]->getScore();
    int *finalRtn = sortCore(finalSort, this->len, 0, this->len - 1);
    delete[] finalSort;
    unsigned int sameRank = 0;
    for (unsigned int i = sameRank; i < this->len - 1; i++)
        if (this->a[finalRtn[sameRank]]->getScore() != this->a[finalRtn[sameRank + 1]]->getScore()) sameRank++;

    if (sameRank == this->len - 1) rtn = genRtnMsg(this->a[finalRtn[this->len - 1]]->getID());
    else {
        rtn = "\nWe found algorithm";
        for (unsigned int i = sameRank; i < this->len; i++) {
            if (i == this->len - 1) rtn += " and";
            else if (i != sameRank) rtn += ", ";
            rtn += " " + charToStr(this->a[finalRtn[i]]->getID()) +
                   getAlgAlterID(this->a[finalRtn[i]]->getID());
        }
        rtn += " have the same performance, and they are ";
        if (this->len - sameRank == 2) rtn += "both";
        else rtn += "all";
        rtn += " the best algorithm.";
    }

    string rankPrt = "";
    for (unsigned int i = 0; i < this->len; i++) {
        rankPrt += "Position " + to_string(i + 1) + ": " +
                   charToStr(this->a[finalRtn[this->len - i - 1]]->getID())
                   + getAlgAlterID(this->a[finalRtn[this->len - i - 1]]->getID())
                   + ": " + to_string(this->a[finalRtn[this->len - i - 1]]->getScore());
        if (i != this->len - 1) rankPrt += "\n";
    }
    delete[] finalRtn;

    rtn += "\n\n*** This conclusion is only responsible for recognized algorithms and input at this execution. ***";
    rtn += "\n*** We do not guarantee the accuracy if either any of registered algorithms or the input changed. ***";
    rtn += "\n*** In case of anything changed, please re-run this program to get a better advice. ***";

    if (flag & 0b100) ::print("\nAll scores:\n" + rankPrt);
    return rtn;
}

void Comparator::print(Cluster *c) {
    ::print("\nRequest list:");
    for (auto iter = this->stdRM->begin(); iter != this->stdRM->end(); iter++) printRequest(iter->second);
    ::print();
    for (unsigned int i = 0; i < this->len; i++) {
        a[i]->print(c);
        ::print();
    }
    ::print("Alternative algorithm IDs");
    for (auto iter = this->alterID->begin(); iter != this->alterID->end(); iter++)
        printf("%s: %s\n", strToChar(iter->first), strToChar(iter->second));
}

