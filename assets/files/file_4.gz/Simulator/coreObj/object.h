//
// Created by Tongxuan on 2019-07-12.
//

#ifndef SCHEDULER_OBJECT_H
#define SCHEDULER_OBJECT_H

#ifdef __cplusplus
extern "C" {
#endif

#define IPT_L_MAX 1024
#define IPT_LEN_MAX 4096

struct para {
    char *id;
    unsigned int var;
};

struct techFlex {
    unsigned int len;
    struct para **p;
};

struct cluster {
    struct techFlex *t;
};

struct request {
    char *RID;
    unsigned int prio, exeLength, pushTime;
    unsigned int exeSeq, exeTimeStamp, totalWaitTime;
    float adjPrio;
    struct techFlex *t;
};

struct requestNode{
    struct requestNode *prev;
    struct request *r;
    struct requestNode *next;
};

struct requestList{
    struct requestNode *head;
    struct requestNode *tail;
    unsigned int length;
};

struct status {
    // When updating the status map, treat ALL Rem C, G and M as how much the resources requested, not reminding.
    unsigned int timeStart;
    unsigned int timeTerminate;
    struct techFlex *t;
};

struct statusNode {
    struct statusNode *prev;
    struct status *s;
    struct statusNode *next;
};

struct statusList {
    struct statusNode *head;
    struct statusNode *tail;
    unsigned int length;
};

struct mapNode {
    unsigned int time;
    struct techFlex *t;
};

struct mapConnector {
    struct mapConnector *prev;
    struct mapNode *n;
    struct mapConnector *next;
};

struct statusMap {
    struct mapConnector *head;
    struct mapConnector *tail;
    unsigned int length;
};

struct scheduler {
    struct requestList *jobList;
    struct requestList *sortedJobList;
    struct statusList *sttList;
    struct statusMap *sttMap;
    double expExeTime;
};

struct initializer {
    struct requestList *rl;
    struct cluster *cl;
    struct scheduler *s;
};

struct strArr {
    int length;
    char **argc;
};

typedef struct para Para;
typedef Para ** plist;
typedef struct techFlex TF;
typedef struct cluster Cluster;
typedef struct request Request;
typedef struct requestNode RequestNode;
typedef struct requestList RequestList;
typedef struct status Status;
typedef struct statusNode StatusNode;
typedef struct statusList StatusList;
typedef struct mapNode MapNode;
typedef struct mapConnector MapConnector;
typedef struct statusMap StatusMap;
typedef struct scheduler Scheduler;
typedef struct initializer Initializer;
typedef struct strArr StrVec;

Para * newPara(char *, unsigned int);
Para * copyPara(Para *);
Para * movePara(Para *);
void deletePara(Para *);

plist newPlist(unsigned int);
plist copyPlist(unsigned int, plist);
plist movePlist(unsigned int, plist);
void deletePlist(unsigned int, plist);

TF * newTF(unsigned int, plist);
TF * copyTF(TF *);
TF * moveTF(TF *);
void deleteTF(TF *);

Cluster * newCluster(unsigned int, Para * *);
Cluster * copyCluster(Cluster *);
Cluster * moveCluster(Cluster *);
void deleteCluster(Cluster *);

Request * newRequest(char *, unsigned int, unsigned int, unsigned int, unsigned int, plist);
Request * copyRequest(Request *);
Request * moveRequest(Request *);
void deleteRequest(Request *);

RequestNode * newRequestNode(Request *);
RequestNode * copyReqeustNode(RequestNode *);
RequestNode * moveReqeustNode(RequestNode *);
void deleteRequestNode(RequestNode *);

RequestList * newRequestList();
RequestList * copyRequestList(RequestList *);
RequestList * moveRequestList(RequestList *);
void deleteRequestList(RequestList *);

Status * newStatus(unsigned int, unsigned int, unsigned int, plist);
Status * copyStatus(Status *);
Status * moveStatus(Status *);
void deleteStatus(Status *);

StatusNode * newStatusNode(Status *);
StatusNode * copyStatusNode(StatusNode *);
StatusNode * moveStatusNode(StatusNode *);
void deleteStatusNode(StatusNode *);

StatusList * newStatusList();
StatusList * copyStatusList(StatusList *);
StatusList * moveStatusList(StatusList *);
void deleteStatusList(StatusList *);

MapNode * newMapNode(unsigned int, unsigned int, plist);
MapNode * copyMapNode(MapNode *);
MapNode * moveMapNode(MapNode *);
void deleteMapNode(MapNode *);

MapConnector * newMapConnector(MapNode *);
MapConnector * copyMapConnector(MapConnector *);
MapConnector * moveMapConnector(MapConnector *);
void deleteMapConnector(MapConnector *);

StatusMap * newStatusMap();
StatusMap * copyStatusMap(StatusMap *);
StatusMap * moveStatusMap(StatusMap *);
void deleteStatusMap(StatusMap *);

Scheduler * newScheduler();
Scheduler * copyScheduler(Scheduler *);
Scheduler * moveScheduler(Scheduler *);
void deleteScheduler(Scheduler *);

Initializer *newInit(RequestList *, Cluster *, Scheduler *);
Initializer * copyInit(Initializer *);
Initializer * moveInit(Initializer *);
void deleteInit(Initializer *);

StrVec * newStrVec(unsigned int, char **);
StrVec * copyStrVec(StrVec *);
StrVec * moveStrVec(StrVec *);
void deleteStrVec(StrVec *);

void requestListInsert(RequestList *, Request *);
void requestListDeleteEleReq(RequestList *, Request *);
void requestListDeleteEleSeq(RequestList *, unsigned int);
void requestListDeleteEleRID(RequestList *, char *);

void statusListInsert(StatusList *, Status *);
void statusMapInsert(StatusMap *, MapNode *);

void printCluster(Cluster *);
void printRequest(Request *);
void printRequestSimu(Request *);
void printRequestNode(RequestNode *);
void printRequestList(RequestList *);
void printRequestListSimu(RequestList *);
void printStatus(Status *, Cluster *);
void printStatusNode(StatusNode *, Cluster *);
void printStatusList(StatusList *, Cluster *);
void printMapNode(unsigned int, MapNode *, Cluster *);
void printMapConnector(MapConnector *, Cluster *);
void printStatusMap(StatusMap *, Cluster *);
void printStrVec(StrVec *);
void printTF(TF *);

bool isIdle(TF *);

#ifdef __cplusplus
};
#endif

#endif //SCHEDULER_OBJECT_H
