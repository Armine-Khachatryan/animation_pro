//
// Created by Tongxuan on 2019-07-28.
//

#include <cstring>

#include "../util.h"
#include "algorithmObj.h"
#include "objService.h"
#include "serviceObject.h"

Algorithm::Algorithm(const char *id, const char *cont, map<string, Request *> *stdRM, Cluster *cl, TF *stdTF) {
    this->id = (char *)calloc(64, sizeof(char));
    if (id != nullptr && strcmp(id, "") != 0) strcpy(this->id, id);
    else strcpy(this->id, strToChar(genID("AG")));

    valid = true;
    vector<string> contVec = split(charToStr(cont), "\n");
    if (contVec.size() != stdRM->size()) goto falseLength;

    this->rm = new map<string, unsigned int>;
    for (unsigned int i = 0; i < stdRM->size(); i++) {
        vector<string> readln = split(contVec[i], " ");
        if (readln.size() < 2) {
            this->rm->insert(make_pair(readln[0], 0));
            continue;
        }
        this->rm->insert(make_pair(readln[0], stringToUnNum(readln[1])));
    }

    for (auto iter = stdRM->begin(); iter != stdRM->end(); iter++) if (this->rm->count(iter->first) == 0) goto falseCont;

    this->sm = newStatusMap();
    for (auto iter = this->rm->begin(); iter != this->rm->end(); iter++) {
        Request *tmp = stdRM->find(iter->first)->second;
        unsigned int exeT = this->rm->find(tmp->RID)->second;
        Status *tmpS = newStatus(exeT, exeT + tmp->exeLength, tmp->t->len, tmp->t->p);
        this->sm = moveStatusMap(updateStatusMap(this->sm, tmpS, stdTF));
        deleteStatus(tmpS);
    }

    for (MapConnector *tmp = this->sm->head; tmp != nullptr; tmp = tmp->next)
        for (unsigned int i = 0; i < tmp->n->t->len; i++)
            if (tmp->n->t->p[i]->var > cl->t->p[i]->var) goto falseCap;

    this->score = 0.0;

    return;

    falseCap:
    deleteStatusMap(this->sm);

    falseCont:
    deleteMap(this->rm);

    falseLength:
    this->sm = nullptr;
    this->valid = false;
}

Algorithm::Algorithm(const Algorithm &s) {
    if (this == &s) return;
    this->valid = s.valid;
    if (!this->valid) goto fin;

    this->sm = copyStatusMap(s.sm);
    this->rm = new map<string, unsigned int>;
    *(this->rm) = *(s.rm);
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->score = s.score;

    fin:
    return;
}

Algorithm &Algorithm::operator=(const Algorithm &s) {
    if (this == &s) return *this;
    this->valid = s.valid;
    if (!this->valid) goto fin;

    this->sm = copyStatusMap(s.sm);
    this->rm = new map<string, unsigned int>;
    *(this->rm) = *(s.rm);
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->score = s.score;

    fin:
    return *this;
}

Algorithm::Algorithm(Algorithm &&s) {
    if (this == &s) return;
    this->valid = s.valid;
    if (!this->valid) goto fin;

    this->sm = copyStatusMap(s.sm);
    this->rm = new map<string, unsigned int>;
    *(this->rm) = *(s.rm);
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->score = s.score;

    fin:
    delete &s;
}

Algorithm &Algorithm::operator=(Algorithm &&s) {
    if (this == &s) return *this;
    this->valid = s.valid;
    if (!this->valid) goto fin;

    this->sm = copyStatusMap(s.sm);
    this->rm = new map<string, unsigned int>;
    *(this->rm) = *(s.rm);
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->score = s.score;

    fin:
    delete &s;
    return *this;
}

Algorithm::~Algorithm() {
    if (!this->valid) return;
    this->valid = false;
    free(this->id);
    this->id = nullptr;
    deleteStatusMap(this->sm);
    this->sm = nullptr;
    deleteMap(this->rm);
    this->rm = nullptr;
    this->score = 0.0;
    return;
}

void Algorithm::print(Cluster *c) {
    ::print("Algorithm " + charToStr(this->id));
    if (! this->valid) return ::print("Invalid algorithm");
    printStatusMap(this->sm, c);
    ::print("Score: " + to_string(this->score));
}

