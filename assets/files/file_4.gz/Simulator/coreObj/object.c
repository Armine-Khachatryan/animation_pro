//
// Created by Tongxuan on 2019-07-12.
//

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "object.h"

#define ID_SIZE 64

Para *newPara(char *id, unsigned int var) {
    Para *rtn = malloc(sizeof(Para));
    rtn->id = calloc(ID_SIZE, sizeof(char));
    if (id != NULL) strcpy(rtn->id, id);
    else
        strcpy(rtn->id, "UNTITLED_PARAMETER");
    rtn->var = var;
    return rtn;
}

Para *copyPara(Para *p) {
    if (p == NULL) return newPara("UNKNOWN", 0);
    return newPara(p->id, p->var);
}

Para *movePara(Para *p) {
    Para *rtn = copyPara(p);
    deletePara(p);
    return rtn;
}

void deletePara(Para *p) {
    if (p == NULL) return;
    free(p->id);
    p->id = NULL;
    p->var = 0;
    free(p);
    p = NULL;
}

plist newPlist(unsigned int len) {
    return calloc(len, sizeof(Para *));
}

plist copyPlist(unsigned int len, plist p) {
    plist rtn = calloc(len, sizeof(Para *));
    for (unsigned int i = 0; i < len; i++) rtn[i] = copyPara(p[i]);
    return rtn;
}

plist movePlist(unsigned int len, plist p) {
    plist rtn = copyPlist(len, p);
    deletePlist(len, p);
    return rtn;
}

void deletePlist(unsigned int len, plist p) {
    for (unsigned int i = 0; i < len; i++) deletePara(p[i]);
    free(p);
    p = NULL;
}

TF * newTF(unsigned int len, plist p) {
    TF *rtn = malloc(sizeof(TF));
    rtn->len = len;
    rtn->p = newPlist(len);
    for (unsigned int i = 0; i < len; i++) rtn->p[i] = copyPara(p[i]);
    return rtn;
}

TF * copyTF(TF *t) {
    return newTF(t->len, t->p);
}

TF * moveTF(TF *t) {
    TF *rtn = copyTF(t);
    deleteTF(t);
    return rtn;
}

void deleteTF(TF *t) {
    deletePlist(t->len, t->p);
    t->len = 0;
    free(t);
    t = NULL;
}

Cluster *newCluster(unsigned int size, plist p) {
    Cluster *rtn = malloc(sizeof(Cluster));
    rtn->t = newTF(size, p);
    return rtn;
}

Cluster *copyCluster(Cluster *c) {
    return newCluster(c->t->len, c->t->p);
}

Cluster *moveCluster(Cluster *c) {
    Cluster *rtn = copyCluster(c);
    deleteCluster(c);
    return rtn;
}

void deleteCluster(Cluster *c) {
    if (c == NULL) return;
    deleteTF(c->t);
    free(c);
    c = NULL;
}

Request *
newRequest(char *id, unsigned int pu, unsigned int prio, unsigned int e, unsigned int length, plist p) {
    Request *rtn = malloc(sizeof(Request));
    rtn->RID = calloc(64, sizeof(char));
    if (id == NULL) strcpy(rtn->RID, "");
    else
        strcpy(rtn->RID, id);
    rtn->pushTime = pu;
    rtn->prio = prio;
    rtn->exeLength = e;
    rtn->exeTimeStamp = 0xFFFF;
    rtn->exeSeq = 0xFFFF;
    rtn->adjPrio = (float) prio;
    rtn->totalWaitTime = 0;
    rtn->t = newTF(length, p);
    return rtn;
}

Request *copyRequest(Request *r) {
    Request *rtn = malloc(sizeof(Request));
    *rtn = *r;
    rtn->RID = calloc(64, sizeof(char));
    strcpy(rtn->RID, r->RID);
    rtn->t = copyTF(r->t);
    return rtn;
}

Request *moveRequest(Request *r) {
    Request *rtn = copyRequest(r);
    deleteRequest(r);
    return rtn;
}

void deleteRequest(Request *r) {
    if (r == NULL) return;
    free(r->RID);
    r->RID = NULL;
    r->pushTime = 0;
    r->prio = 0;
    r->exeLength = 0;
    r->exeTimeStamp = 0;
    r->exeSeq = 0;
    r->adjPrio = 0.0;
    r->totalWaitTime = 0;
    deleteTF(r->t);
    free(r);
    r = NULL;
}

RequestNode *newRequestNode(Request *r) {
    RequestNode *rn = malloc(sizeof(RequestNode));
    rn->prev = NULL;
    rn->next = NULL;
    rn->r = copyRequest(r);
    return rn;
}


RequestNode *copyReqeustNode(RequestNode *rn) {
    return newRequestNode(rn->r);
}

RequestNode *moveReqeustNode(RequestNode *rn) {
    RequestNode *rtn = copyReqeustNode(rn);
    deleteRequestNode(rn);
    return rtn;
}

void deleteRequestNode(RequestNode *rn) {
    if (rn == NULL) return;
    rn->next = NULL;
    rn->prev = NULL;
    deleteRequest(rn->r);
    rn->r = NULL;
    free(rn);
    rn = NULL;
}

RequestList *newRequestList() {
    RequestList *rtn = malloc(sizeof(RequestList));
    rtn->head = NULL;
    rtn->tail = NULL;
    rtn->length = 0;
    return rtn;
}


RequestList *copyRequestList(RequestList *rl) {
    if (rl == NULL) return newRequestList();
    RequestList *rtn = newRequestList();
    for (RequestNode *tmp = rl->head; tmp != NULL; tmp = tmp->next) requestListInsert(rtn, tmp->r);
    return rtn;
}

RequestList *moveRequestList(RequestList *rl) {
    RequestList *rtn = copyRequestList(rl);
    deleteRequestList(rl);
    return rtn;
}

void deleteRequestList(RequestList *rl) {
    if (rl == NULL) return;
    while (rl->length > 0) {
        RequestNode *tmp = rl->head;
        rl->head = rl->head->next;
        deleteRequestNode(tmp);
        rl->length--;
    }
    rl->head = NULL;
    rl->tail = NULL;
    rl->length = 0;
    free(rl);
    rl = NULL;
}

Status *newStatus(unsigned int s, unsigned int t, unsigned int length, plist p) {
    Status *rtn = malloc(sizeof(Status));
    rtn->timeStart = s;
    rtn->timeTerminate = t;
    rtn->t = newTF(length, p);
    return rtn;
}

Status *copyStatus(Status *s) {
    return newStatus(s->timeStart, s->timeTerminate, s->t->len, s->t->p);
}

Status *moveStatus(Status *s) {
    Status *rtn = copyStatus(s);
    deleteStatus(s);
    return rtn;
}

void deleteStatus(Status *s) {
    if (s == NULL) return;
    deleteTF(s->t);
    s->timeTerminate = 0;
    s->timeStart = 0;
    free(s);
    s = NULL;
}

StatusNode *newStatusNode(Status *s) {
    StatusNode *rtn = malloc(sizeof(StatusNode));
    rtn->next = NULL;
    rtn->prev = NULL;
    rtn->s = copyStatus(s);
    return rtn;
}

StatusNode *copyStatusNode(StatusNode *sn) {
    return newStatusNode(sn->s);
}

StatusNode *moveStatusNode(StatusNode *sn) {
    StatusNode *rtn = copyStatusNode(sn);
    deleteStatusNode(sn);
    return rtn;
}

void deleteStatusNode(StatusNode *sn) {
    if (sn == NULL) return;
    sn->prev = NULL;
    sn->next = NULL;
    deleteStatus(sn->s);
    sn->s = NULL;
    free(sn);
    sn = NULL;
}

StatusList *newStatusList() {
    StatusList *rtn = malloc(sizeof(StatusList));
    rtn->tail = NULL;
    rtn->length = 0;
    rtn->head = NULL;
    return rtn;
}

StatusList *copyStatusList(StatusList *sl) {
    StatusList *rtn = newStatusList();
    for (StatusNode *tmp = sl->head; tmp != NULL; tmp = tmp->next) statusListInsert(rtn, tmp->s);
    return rtn;
}

StatusList *moveStatusList(StatusList *sl) {
    StatusList *rtn = copyStatusList(sl);
    deleteStatusList(sl);
    return rtn;
}

void deleteStatusList(StatusList *sl) {
    if (sl == NULL) return;
    while (sl->head != NULL) {
        StatusNode *tmp = sl->head->next;
        deleteStatusNode(sl->head);
        sl->head = tmp;
        sl->length--;
    }
    free(sl);
    sl = NULL;
}

MapNode *newMapNode(unsigned int t, unsigned int length, plist p) {
    MapNode *rtn = malloc(sizeof(MapNode));
    rtn->time = t;
    rtn->t = newTF(length, p);
    return rtn;
}

MapNode *copyMapNode(MapNode *mn) {
    return newMapNode(mn->time, mn->t->len, mn->t->p);
}

MapNode *moveMapNode(MapNode *mn) {
    MapNode *rtn = copyMapNode(mn);
    deleteMapNode(mn);
    return rtn;
}

void deleteMapNode(MapNode *mn) {
    if (mn == NULL) return;
    mn->time = 0;
    deleteTF(mn->t);
    free(mn);
    mn = NULL;
}

MapConnector *newMapConnector(MapNode *mn) {
    MapConnector *rtn = malloc(sizeof(MapConnector));
    rtn->prev = NULL;
    rtn->next = NULL;
    rtn->n = copyMapNode(mn);
    return rtn;
}

MapConnector *copyMapConnector(MapConnector *mc) {
    return newMapConnector(mc->n);
}

MapConnector *moveMapConnector(MapConnector *mc) {
    MapConnector *rtn = copyMapConnector(mc);
    deleteMapConnector(mc);
    return rtn;
}

void deleteMapConnector(MapConnector *mc) {
    if (mc == NULL) return;
    mc->next = NULL;
    mc->prev = NULL;
    deleteMapNode(mc->n);
    free(mc);
    mc = NULL;
}

StatusMap *newStatusMap() {
    StatusMap *rtn = malloc(sizeof(StatusMap));
    rtn->tail = NULL;
    rtn->head = NULL;
    rtn->length = 0;
    return rtn;
}

StatusMap *copyStatusMap(StatusMap *sm) {
    StatusMap *rtn = newStatusMap();
    for (MapConnector *tmp = sm->head; tmp != NULL; tmp = tmp->next) statusMapInsert(rtn, tmp->n);
    return rtn;
}

StatusMap *moveStatusMap(StatusMap *sm) {
    StatusMap *rtn = copyStatusMap(sm);
    deleteStatusMap(sm);
    return rtn;
}

void deleteStatusMap(StatusMap *sm) {
    if (sm == NULL) return;
    while (sm->head != NULL) {
        MapConnector *tmp = sm->head->next;
        deleteMapConnector(sm->head);
        sm->head = tmp;
        sm->length--;
    }
    sm->length = 0;
    sm->tail = NULL;
    sm->head = NULL;
    free(sm);
    sm = NULL;
}

Scheduler *newScheduler() {
    Scheduler *rtn = malloc(sizeof(Scheduler));
    rtn->jobList = newRequestList();
    rtn->sortedJobList = newRequestList();
    rtn->sttList = newStatusList();
    rtn->sttMap = newStatusMap();
    rtn->expExeTime = 0.0;
    return rtn;
}

Scheduler *copyScheduler(Scheduler *s) {
    if (s == NULL) return newScheduler();
    Scheduler *rtn = malloc(sizeof(Scheduler));
    rtn->jobList = copyRequestList(s->jobList);
    rtn->sortedJobList = copyRequestList(s->sortedJobList);
    rtn->sttMap = copyStatusMap(s->sttMap);
    rtn->sttList = copyStatusList(s->sttList);
    rtn->expExeTime = s->expExeTime;
    return rtn;
}

Scheduler *moveScheduler(Scheduler *s) {
    Scheduler *rtn = copyScheduler(s);
    deleteScheduler(s);
    return rtn;
}

void deleteScheduler(Scheduler *s) {
    if (s == NULL) return;
    deleteRequestList(s->jobList);
    deleteRequestList(s->sortedJobList);
    deleteStatusMap(s->sttMap);
    deleteStatusList(s->sttList);

    s->expExeTime = 0.0;
    free(s);
    s = NULL;
}

Initializer *newInit(RequestList *rl, Cluster *cl, Scheduler *s) {
    Initializer *rtn = malloc(sizeof(Initializer));
    rtn->cl = copyCluster(cl);
    rtn->rl = copyRequestList(rl);
    rtn->s = copyScheduler(s);
    return rtn;
}

Initializer *copyInit(Initializer *s) {
    return newInit(s->rl, s->cl, s->s);
}

Initializer *moveInit(Initializer *s) {
    Initializer *rtn = copyInit(s);
    deleteInit(s);
    return rtn;
}

void deleteInit(Initializer *s) {
    if (s == NULL) return;
    deleteRequestList(s->rl);
    deleteCluster(s->cl);
    deleteScheduler(s->s);

    free(s);
    s = NULL;
}

StrVec *newStrVec(unsigned int l, char **c) {
    StrVec *rtn = malloc(sizeof(StrVec));
    if (c == NULL || l == 0) return rtn;
    rtn->length = l;
    rtn->argc = calloc(l, sizeof(char *));
    for (unsigned int i = 0; i < l; i++) {
        if (c[i] == NULL) {
            rtn->length = l;
            break;
        }
        rtn->argc[i] = calloc(IPT_L_MAX, sizeof(char));
        strcpy(rtn->argc[i], c[i]);
    }
    return rtn;
}

StrVec *copyStrVec(StrVec *s) {
    if (s == NULL) return newStrVec(0, NULL);
    return newStrVec(s->length, s->argc);
}

StrVec *moveStrVec(StrVec *s) {
    StrVec *rtn = copyStrVec(s);
    deleteStrVec(s);
    return rtn;
}

void deleteStrVec(StrVec *s) {
    if (s == NULL) return;
    for (unsigned int i = 0; i < s->length; i++) {
        free(s->argc[i]);
        s->argc[i] = NULL;
    }
    s->length = 0;
    free(s->argc);
    s->argc = NULL;
    free(s);
    s = NULL;
}

void requestListInsert(RequestList *rl, Request *r) {
    if (rl == NULL || r == NULL) return;
    RequestNode *rn = newRequestNode(r);
    if (rl->length == 0) {
        rl->head = rn;
        rl->tail = rn;
    } else {
        rl->tail->next = rn;
        rn->prev = rl->tail;
        rl->tail = rn;
    }
    rl->length++;
}

bool equalsParaList(plist p1, unsigned int para1Len, plist p2, unsigned int para2Len) {
    if (para1Len != para2Len) return false;
    for (unsigned int i = 0; i < para1Len; i++)
        if (!(strcmp(p1[i]->id, p2[i]->id) == 0 && p1[i]->var == p2[i]->var)) return false;
    return true;
}

bool equalsRequest(Request *r1, Request *r2) {
    if (r1 == NULL || r2 == NULL) return false;
    if (strcmp(r1->RID, r2->RID) != 0) return false;
    if (r1->pushTime != r2->pushTime) return false;
    if (r1->prio != r2->prio) return false;
    if (!equalsParaList(r1->t->p, r1->t->len, r2->t->p, r2->t->len)) return false;
    if (r1->exeLength != r2->exeLength) return false;
    return true;
}

void requestListDeleteEleReq(RequestList *rl, Request *r) {
    RequestNode *tmp = rl->head;
    while (tmp != NULL) {
        if (!equalsRequest(tmp->r, r)) {
            tmp = tmp->next;
            continue;
        }
        RequestNode *tmp2 = tmp;
        tmp = tmp->next;
        if (tmp2->next != NULL) tmp2->next->prev = tmp2->prev;
        else rl->tail = tmp2->prev;
        if (tmp2->prev != NULL) tmp2->prev->next = tmp2->next;
        else rl->head = tmp2->next;
        deleteRequestNode(tmp2);
        rl->length--;
    }
}

void requestListDeleteEleSeq(RequestList *rl, unsigned int seq) {
    if (seq > rl->length - 1) return;
    RequestNode *tmp = rl->head;
    for (unsigned int i = 1; i < seq; i++) tmp = tmp->next;
    requestListDeleteEleReq(rl, tmp->r);
}

void requestListDeleteEleRID(RequestList *rl, char *id) {
    RequestNode *tmp = rl->head;
    while (tmp != NULL) {
        if (strcmp(id, tmp->r->RID) == 0) break;
        tmp = tmp->next;
    }
    if (tmp == NULL) return;
    requestListDeleteEleReq(rl, tmp->r);
}

void statusListInsert(StatusList *sl, Status *s) {
    if (sl == NULL || s == NULL) return;
    StatusNode *sn = newStatusNode(s);
    if (sl->length == 0) {
        sl->head = sn;
        sl->tail = sn;
    } else {
        sl->tail->next = sn;
        sn->prev = sl->tail;
        sl->tail = sn;
    }
    sl->length++;
}

void statusMapInsert(StatusMap *sm, MapNode *mn) {
    if (sm == NULL || mn == NULL) return;
    MapConnector *mc = newMapConnector(mn);
    if (sm->length == 0) {
        sm->head = mc;
        sm->tail = mc;
    } else {
        sm->tail->next = mc;
        mc->prev = sm->tail;
        sm->tail = mc;
    }
    sm->length++;
}

void printCluster(Cluster *c) {
    printf("Cluster: ");
    for (unsigned int i = 0; i < c->t->len; i++)
        i == 0 ? printf("%s %u", c->t->p[i]->id, c->t->p[i]->var) : printf(", %s %u", c->t->p[i]->id,
                                                                                    c->t->p[i]->var);
    printf("\n");
}

void printRequest(Request *r) {
    printf("Request %s: Push time %u, Priority %u", r->RID, r->pushTime, r->prio);
    for (unsigned int i = 0; i < r->t->len; i++) printf(", %s %u", r->t->p[i]->id, r->t->p[i]->var);
    printf(", Execution Timestamp %u\n", r->exeTimeStamp);
}

void printRequestSimu(Request *r) {
    printf("%s %u\n", r->RID, r->exeTimeStamp);
}

void printRequestNode(RequestNode *rn) {
    printRequest(rn->r);
}

void printRequestList(RequestList *rl) {
    for (RequestNode *rn = rl->head; rn != NULL; rn = rn->next) printRequestNode(rn);
}

void printRequestListSimu(RequestList *rl) {
    RequestNode *rn = rl->head;
    while (rn != NULL) {
        printRequestSimu(rn->r);
        rn = rn->next;
    }
}

void printStatus(Status *s, Cluster *c) {
    if (s == NULL) {
        printf("Status closed");
        return;
    }

    printf("From %4d, until %4d: ", s->timeStart, s->timeTerminate);
    printTF(s->t);
    if (isIdle(s->t)) printf("\t (Idle)\n");
    else {
        float sttOverall = 0.0f;
        float cstOverall = 0.0f;
        for (unsigned int i = 0; i < s->t->len; i++) {
            if (i > 0) printf(", ");
            printf("%s %6.2f%%", s->t->p[i]->id, (float) s->t->p[i]->var / c->t->p[i]->var);
            sttOverall += s->t->p[i]->var;
            cstOverall += c->t->p[i]->var;
        } printf(", Overall %6.2f%%\n", sttOverall * 100 / cstOverall);
    }
}

void printStatusNode(StatusNode *sn, Cluster *c) {
    printStatus(sn->s, c);
}

void printStatusList(StatusList *sl, Cluster *c) {
    for (StatusNode *tmp = sl->head; tmp != NULL; tmp = tmp->next) printStatusNode(tmp, c);
}

void printMapNode(unsigned int prev, MapNode *mn, Cluster *c) {
    if (mn == NULL) {
        printf("Status closed");
        return;
    }

    printf("From %4d, until %4d: ", prev, mn->time);
    printTF(mn->t);
    if (isIdle(mn->t)) printf("\t (Idle)\n");
    else {
        float sttOverall = 0.0f;
        float cstOverall = 0.0f;
        printf("\t ");
        for (unsigned int i = 0; i < mn->t->len; i++) {
            if (i > 0) printf(", ");
            printf("%s %6.2f%%", mn->t->p[i]->id, (float) mn->t->p[i]->var * 100 / c->t->p[i]->var);
            sttOverall += mn->t->p[i]->var;
            cstOverall += c->t->p[i]->var;
        } printf(", Overall %6.2f%%\n", sttOverall * 100 / cstOverall);
    }
}

void printMapConnector(MapConnector *mc, Cluster *c) {
    if (mc->prev == NULL && isIdle(mc->n->t)) return;
    mc->prev == NULL ? printMapNode(0, mc->n, c) : printMapNode(mc->prev->n->time, mc->n, c);
}

void printStatusMap(StatusMap *sm, Cluster *c) {
    if (sm->length == 0) printf("Empty map\n");
    for (MapConnector *mc = sm->head; mc != NULL; mc = mc->next) printMapConnector(mc, c);
}

void printTF(TF *t) {
    for (unsigned int i = 0; i < t->len; i++)
        i == 0 ? printf("%s %3u", t->p[i]->id, t->p[i]->var) : printf(", %s %3u", t->p[i]->id, t->p[i]->var);
}

bool isIdle(TF *t) {
    if (t->len == 0) return true;
    for (unsigned int i = 0; i < t->len; i++) if (t->p[i]->var != 0) return false;
    return true;
}

