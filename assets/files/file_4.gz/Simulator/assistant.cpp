//
// Created by Tongxuan on 2019-07-28.
//

#include <thread>
#include <cstring>

#include "assistant.h"
#include "coreObj/objService.h"
#include "coreObj/object.h"
#include "util.h"
#include "coreObj/algorithmObj.h"
#include "coreObj/serviceObject.h"
#include "coreObj/comparator.h"
#include "service/att.h"

void Assistant::genTestCase(unsigned int flag) {
    if (!dirExist(".algorithm")) runShell("mkdir .algorithm");
    srand((unsigned) time(nullptr));
    string rtn = "CPU GPU MEM\n";
    string src = to_string((rand() % 0x11) + 0x50);
    rtn += src + " " + src + " " + src + "\n";
    int loop = (rand() % (0x40 - 0x30 + 1)) + 0x60;
    int cH = loop * 0.3;
    int gH = loop * 0.2;
    int mH = loop - cH - gH;

    for (int i = 0; i < cH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1)) + 0x0);
        rtn += genID("RC") + " " + push + " " + prio + " " + exe + " " + maxS + " " + minS + " " + minS + "\n";
    }
    for (int i = 0; i < gH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1)) + 0x0);
        rtn += genID("RP") + " " + push + " " + prio + " " + exe + " " + minS + " " + maxS + " " + minS + "\n";
    }
    for (int i = 0; i < mH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1)) + 0x0);
        rtn += genID("RM") + " " + push + " " + prio + " " + exe + " " + minS + " " + minS + " " + maxS + "\n";
    }
    string tar = "request.conf";
    string tarAdd = ".algorithm";
    string mode = "w";
    writeFile(rtn.c_str(), tarAdd, tar.c_str(), mode.c_str());
    if (!(flag & 0b1000)) ::print("Test case been generated automatically");
}

void Assistant::regNewAlg(string &n, string &r, string &e) {
    string nOri = n;
    string eOri = e;
    if (!validate(n, r, e, "a")) return print("Illegal target or target exists.");

    string dir = ".algorithm";
    string cmd;
    if (!dirExist(dir)) {
        cmd = "mkdir " + dir;
        runShell(cmd.c_str());
    }
    cmd = "cp -r " + r.substr(0, r.length() - 1) + " .algorithm/" + n;
    runShell(cmd.c_str());
    string base = ".algorithm/";
    string genExe = n + ".sh";
    string genR = "./" + n;
    genTarAlgSh(n, e, base, genExe, genR);

    string mode = "w";
    string tar = "algorithm.conf";
    string id = genID("AG");
    string cont = readFile(".algorithm/algorithm.conf") + genDes(id, nOri, eOri);

    writeFile(cont.c_str(), ".algorithm", tar.c_str(), mode.c_str());
}

void Assistant::update(string &name, string &root, string &exe) {
    if (validate(name, root, exe, "u") == false) return print("Cannot locate new executable file.\nUpdate completed.");
    if (remove(name) == "Removed.") {
        this->regNewAlg(name, root, exe);
        return print("Update completed.");
    } else return print("Target not found, use -a flag.\nUpdate completed.");
}

string Assistant::remove(string &name) {
    string rtn = "";
    bool flag = false;
    vector<vector<string> > *rtnVec = ::loadRegAlg();
    for (unsigned int i = 0; i < rtnVec->size(); i++) {
        if ((*rtnVec)[i][1] == name) {
            string cmd = "";
            cmd = "rm -rf .algorithm/" + name + "*";
            runShell(cmd.c_str());
            flag = true;
            continue;
        }
        rtn += (*rtnVec)[i][0] + "  " + (*rtnVec)[i][1] + "  " + (*rtnVec)[i][2] + "\n";
    }
    delete rtnVec;
    if (flag) {
        string dir = ".algorithm";
        string tar = "algorithm.conf";
        string mode = "w";
        writeFile(rtn.c_str(), dir, tar.c_str(), mode.c_str());
        rtn = "Removed.";
        print(rtn);
        return rtn;
    } else {
        rtn = "Target not found.\nRemove completed.";
        print(rtn);
        return rtn;
    }
}

void deleteMap(map<string, Request *> *m) {
    if (m == nullptr) return;
    while (m->size() > 0) {
        deleteRequest(m->begin()->second);
        m->begin()->second = nullptr;
        m->erase(m->begin());
    }
    delete m;
    m = nullptr;
}

Algorithm **aArr;

void threadRunnable(void *att) {
    ATT *a = (ATT *) att;
    aArr[a->getIndex()] = new Algorithm(strToChar(a->getID()),
                                        strToChar(runShell(".algorithm/" + charToStr(a->getAlter()) + ".sh")),
                                        a->getMap(), a->getCluster(), a->getT());
    delete a;
}

string Assistant::compare(unsigned int flag) {

    string finalTimeAna = "";
    long long int startTime = getUnixTime();
    long long int baseTime = getUnixTime();
    if (!(flag & 0b1000)) ::print("Loading configurations");

    vector<string> conf = loadReqConf();
    if (conf.size() < 3) return "Illegal configure file";

    vector<string> header = split(conf[0], " ");
    if (header.size() < 1) return "Insufficient header length";

    vector<string> clusterVec = split(conf[1], " ");
    if (clusterVec.size() > header.size()) return "Insufficient cluster defintion";

    vector<vector<string> > reqConfVec;
    for (unsigned int i = 2; i < conf.size(); i++) {
        vector<string> reqVec = split(conf[i], " ");
        if (reqVec.size() < header.size() + 4)
            return "Insufficient request definition at line " + to_string(i) + ": " + conf[i];
        reqConfVec.push_back(reqVec);
    }

    plist std = newPlist(header.size());
    for (unsigned int i = 0; i < header.size(); i++) {
        char *id = constToFlex(strToChar(header[i]));
        std[i] = newPara(id, 0);
        free(id);
    }

    plist clusterPlist = copyPlist(header.size(), std);
    for (unsigned int i = 0; i < header.size(); i++) clusterPlist[i]->var = stringToUnNum(clusterVec[i]);
    Cluster *cl = newCluster(header.size(), clusterPlist);
    deletePlist(header.size(), clusterPlist);

    auto *stdRM = new map<string, Request *>();
    for (unsigned int i = 0; i < reqConfVec.size(); i++) {
        plist reqPlist = copyPlist(header.size(), std);
        for (unsigned int j = 0; j < header.size(); j++)
            reqPlist[j]->var = stringToUnNum(reqConfVec[i][j + 4]);
        char *id = constToFlex(strToChar(reqConfVec[i][0]));
        Request *tmpR = newRequest(id, stringToUnNum(reqConfVec[i][1]), stringToUnNum(reqConfVec[i][2]),
                                   stringToUnNum(reqConfVec[i][3]), header.size(), reqPlist);
        stdRM->insert(make_pair(charToStr(id), tmpR));
        free(id);
        deletePlist(header.size(), reqPlist);
    }

    Comparator *c;

    TF *stdTF = newTF(header.size(), std);
    vector<vector<string> > *regAlg = loadRegAlg();

    if (regAlg->size() == 0) return "No registered algorithm";
    if (flag & 0b10)
        finalTimeAna +=
                "Input conf process used " + to_string((double) (getUnixTime() - baseTime) / 1000000) +
                " seconds\n";
    baseTime = getUnixTime();
    if (!(flag & 0b1000)) ::print("Loading algorithms");

    string rtn;
    ATT *att;
    thread *threads[regAlg->size()];

    char **runnable = (char **) calloc(regAlg->size(), sizeof(char *));
    if (regAlg->size() < 1) goto emptyList;
    for (unsigned int i = 0; i < regAlg->size(); i++) {
        runnable[i] = (char *) calloc(128, sizeof(char));
        strcpy(runnable[i], strToChar((*regAlg)[i][1]));
    }

    aArr = new Algorithm *[regAlg->size()];
    for (unsigned int i = 0; i < regAlg->size(); i++) {
        att = new ATT(i, (*regAlg)[i][0], runnable[i], stdRM, cl, stdTF);
        threads[i] = new thread(threadRunnable, (void *) att);
        //aArr[i]->print(cl);
    }
    if (!(flag & 0b1000)) ::print("Algorithms loaded into container");
    for (auto &thread : threads) thread->join();

    for (auto &thread : threads) {
        delete thread;
        thread = nullptr;
    }

    if (!(flag & 0b1000)) ::print("Algorithms execution finished\n");
    if (flag & 0b10) finalTimeAna += "Algorithms process used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";
    baseTime = getUnixTime();

    // TODO make brute force
    if (flag & 0b10) finalTimeAna += "Brute force will be process here, used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";

    c = new Comparator(aArr, regAlg->size(), stdRM);
    baseTime = getUnixTime();
    if (!(flag & 0b1000)) rtn = c->doCompare(flag);
    if (flag & 0b10) finalTimeAna += "Comparison used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";
    if (flag & 0b01) c->print(cl);
    if (flag & 0b1000) {
        c->doCompare(0);
        string tmpOtpDir = "/tmp/ASR";
        string currPID = genID("PR");

        string title = "";
        string score = "";
        for (unsigned int i = 0; i < regAlg->size(); i++) {
            title += charToStr(aArr[i]->getID());
            score += to_string(aArr[i]->getScore());
            if (i == regAlg->size() - 1) {
                title += "\n";
                score += "\n";
            } else {
                title += "\t";
                score += "\t";
            }
        }

        unsigned int totalLen = 3 + stdTF->len;
        string algStrArr[totalLen];
        for (unsigned int i = 0; i < stdTF->len; i++)
            if (!fileExist(tmpOtpDir + "/util_" + header[i] + ".txt")) {
                touch(tmpOtpDir + "/util_" + header[i] + ".txt");
                updateFile(title, tmpOtpDir + "/util_" + header[i] + ".txt");
            }

        if (!fileExist(tmpOtpDir + "/r.txt")) {
            touch(tmpOtpDir + "/r.txt");
            updateFile(title, tmpOtpDir + "/r.txt");
        }
        if (!fileExist(tmpOtpDir + "/util_comprehensive.txt")) {
            touch(tmpOtpDir + "/util_comprehensive.txt");
            updateFile(title, tmpOtpDir + "/util_comprehensive.txt");
        }
        if (!fileExist(tmpOtpDir + "/finT.txt")) {
            touch(tmpOtpDir + "/finT.txt");
            updateFile(title, tmpOtpDir + "/finT.txt");
        }

        algStrArr[0] += score;

        for (unsigned int i = 0; i < regAlg->size(); i++) {
            auto titleSeq = split(*split(readFile(strToChar(tmpOtpDir + "/finT.txt")), "\n").begin(), "\t");
            unsigned int tarSeq = 0;
            while (aArr[i]->getID() != (titleSeq)[tarSeq] && tarSeq < regAlg->size()) tarSeq++;

            //double C = 0.0, G = 0.0, M = 0.0;
            double finCal[header.size()];
            for (auto tmp = aArr[i]->getSttMap()->head; tmp != nullptr; tmp = tmp->next) {
                for (unsigned int k = 0; k < tmp->n->t->len; k++) finCal[k] += tmp->n->t->p[k]->var;
            }

            algStrArr[1] += to_string(aArr[i]->getSttMap()->tail->n->time);
            double sumD = 0.0;
            for (unsigned int j = 0; j < header.size(); j++) {
                algStrArr[i + 2] += to_string(finCal[j] / aArr[i]->getSttMap()->length);
                sumD += finCal[j];
            } algStrArr[totalLen - 1] += to_string(sumD / (3 * aArr[i]->getSttMap()->length));

            for (unsigned int j = 1; j < totalLen; j++)
                i == regAlg->size() - 1 ? algStrArr[j] += "\n" : algStrArr[j] += "\t";
        }
        updateFile(algStrArr[0], tmpOtpDir + "/r.txt");
        updateFile(algStrArr[1], tmpOtpDir + "/finT.txt");
        for (unsigned int i = 0; i < stdTF->len; i++)
            updateFile(algStrArr[i + 2], tmpOtpDir + "/util_" + header[i] + ".txt");
        updateFile(algStrArr[totalLen - 1], tmpOtpDir + "/util_comprehensive.txt");
    }
    delete c;

    for (unsigned int i = 0; i < regAlg->size(); i++) {
        free(runnable[i]);
        delete aArr[i];
        aArr[i] = nullptr;
    }

    for (unsigned int i = 0; i < regAlg->size(); i++) delete aArr[i];
    delete[] aArr;
    rmFile(".algorithm/request.conf");

    emptyList:
    deleteTF(stdTF);
    free(runnable);
    delete regAlg;
    deleteMap(stdRM);
    deleteCluster(cl);
    deletePlist(header.size(), std);

    if (flag & 0b10) {
        finalTimeAna += "Function terminating, in total " + to_string((double)(getUnixTime() - startTime) / 1000000) + " seconds\n";
        ::print("\n" + finalTimeAna);
    }

    return rtn;
}

