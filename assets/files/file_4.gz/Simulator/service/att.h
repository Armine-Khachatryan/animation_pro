//
// Created by Tongxuan on 2019-07-28.
//

#ifndef SIMULATORC_ATT_H
#define SIMULATORC_ATT_H

#include "../util.h"
#include "../coreObj/object.h"

class ATT {
private:
    unsigned index;
    string id;
    char *alterID;
    map<string, Request *> *stdRM;
    Cluster *cl;
    TF *stdTF;
public:
    ATT(unsigned int, string, char *, map<string, Request *> *, Cluster *, TF *);
    ATT(const ATT &s) = delete;
    ATT& operator=(const ATT& s) = delete;
    ATT(ATT&& s) = delete;
    ATT& operator=(ATT&& s) = delete;
    ~ATT();

    unsigned int getIndex() {return this->index;}
    string getID() {return this->id;}
    char * getAlter() {return this->alterID;}
    map<string, Request *> * getMap() {return this->stdRM;}
    Cluster * getCluster() {return this->cl;}
    TF * getT() {return this->stdTF;}
};

#endif //SIMULATORC_ATT_H
