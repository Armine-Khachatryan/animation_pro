//
// Created by Tongxuan on 2019-07-28.
//

#include "att.h"

ATT::ATT(unsigned int i, string id, char *alterID, map<string, Request *> *rm, Cluster *c, TF *t) {
    this->index = i;
    this->id = id;
    this->alterID = alterID;
    this->stdRM = rm;
    this->cl = c;
    this->stdTF = t;
}

ATT::~ATT() {
    this->index = 0;
    this->id = "";
}

