//
// Created by Tongxuan on 2019-07-28.
//

#ifndef SIMULATORC_ASSISTANT_H
#define SIMULATORC_ASSISTANT_H

#include "util.h"

class Assistant {
public:
    Assistant() = default;
    Assistant(const Assistant &s) = delete;
    Assistant& operator=(const Assistant& s) = delete;
    Assistant(Assistant&& s) = delete;
    Assistant& operator=(Assistant&& s) = delete;
    ~Assistant() = default;

    void genTestCase(unsigned int flag);
    void regNewAlg(string &, string &, string &);
    void update(string &, string &, string &);
    string remove(string &name);
    string compare(unsigned int);

    static string genDes(string &id, string &n, string &e) {return id + "  " + n + "  " + e + "\n";}
};

#endif //SIMULATORC_ASSISTANT_H
