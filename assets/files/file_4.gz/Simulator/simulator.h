//
// Created by Tongxuan on 2019-07-28.
//

#ifndef SIMULATORC_SIMULATOR_H
#define SIMULATORC_SIMULATOR_H

#include "util.h"

string printList();
string surprise();
string genHelpMsg();
string add(int, char **);
string update(int, char **);
string illegalCmd(int, const string &);
string remove(char *);
string reset();
string compare(unsigned int);
void genTestCase(int, char **);
string genEvalPY();

#endif //SIMULATORC_SIMULATOR_H

