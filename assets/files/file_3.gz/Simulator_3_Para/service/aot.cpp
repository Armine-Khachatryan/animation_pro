//
// Created by Tongxuan on 2019-06-07.
//

#include <cstring>
#include "aot.h"
#include "../util.h"

AOT::AOT(const char *i, const char *c) {
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, i);
    this->content = (char *)calloc(16384, sizeof(char));
    strcpy(this->content, c);
    this->closed = false;
}

AOT::AOT(const AOT &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->content = (char *)calloc(16384, sizeof(char));
    strcpy(this->content, s.content);
}

AOT& AOT::operator=(const AOT& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->content = (char *)calloc(16384, sizeof(char));
    strcpy(this->content, s.content);

    return *this;
}

AOT::AOT(AOT&& s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->content = (char *)calloc(16384, sizeof(char));
    strcpy(this->content, s.content);

    delete &s;
}

AOT& AOT::operator=(AOT&& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->content = (char *)calloc(16384, sizeof(char));
    strcpy(this->content, s.content);

    delete &s;
    return *this;
}

AOT::~AOT() {
    if (this->closed) return;
    this->closed = true;
    free(this->id);
    this->id = nullptr;
    free(this->content);
    this->content = nullptr;
}

