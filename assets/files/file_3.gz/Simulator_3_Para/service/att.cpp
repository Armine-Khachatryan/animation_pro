//
// Created by Tongxuan on 2019-06-07.
//

#include <cstring>
#include "att.h"
#include "../util.h"

ATT::ATT(const char *i, const char *n) {
    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, i);
    this->name = (char *)calloc(64, sizeof(char));
    strcpy(this->name, n);
    this->closed = false;
}

ATT::ATT(const ATT &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->name = (char *)calloc(64, sizeof(char));
    strcpy(this->name, s.name);
}

ATT& ATT::operator=(const ATT& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->name = (char *)calloc(64, sizeof(char));
    strcpy(this->name, s.name);

    return *this;
}

ATT::ATT(ATT&& s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->name = (char *)calloc(64, sizeof(char));
    strcpy(this->name, s.name);

    delete &s;
}

ATT& ATT::operator=(ATT&& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->id = (char *)calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->name = (char *)calloc(64, sizeof(char));
    strcpy(this->name, s.name);

    delete &s;
    return *this;
}

ATT::~ATT() {
    if (this->closed) return;
    this->closed = true;
    free(this->id);
    this->id = nullptr;
    free(this->name);
    this->name = nullptr;
}

