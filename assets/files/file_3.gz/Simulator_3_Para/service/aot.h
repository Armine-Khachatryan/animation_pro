//
// Created by Tongxuan on 2019-06-07.
//

#ifndef SIMULATORCPP_AOT_H
#define SIMULATORCPP_AOT_H

using namespace std;

class AOT {
private:
    char *id;
    char *content;
    bool closed;
public:
    AOT(const char *, const char *);
    AOT(const AOT &s);
    AOT& operator=(const AOT& s);
    AOT(AOT&& s);
    AOT& operator=(AOT&& s);
    ~AOT();

    char * getID() {return this->id;}
    char * getContent() {return this->content;}
};

#endif //SIMULATORCPP_AOT_H
