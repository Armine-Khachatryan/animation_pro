//
// Created by Tongxuan on 2019-06-07.
//

#ifndef SIMULATORCPP_ATT_H
#define SIMULATORCPP_ATT_H

using namespace std;

class ATT {
private:
    char *id;
    char *name;
    bool closed;
public:
    ATT(const char *, const char *);
    ATT(const ATT &s);
    ATT& operator=(const ATT& s);
    ATT(ATT&& s);
    ATT& operator=(ATT&& s);
    ~ATT();

    char * getID() {return this->id;}
    char * getName() {return this->name;}
};

#endif //SIMULATORCPP_ATT_H
