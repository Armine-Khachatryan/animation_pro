//
// Created by Tongxuan on 2019-05-24.
//

#ifndef SIMULATORCPP_ASSISTANT_H
#define SIMULATORCPP_ASSISTANT_H

#include "coreObj/comparator.h"
#include "service/aot.h"
#include "service/att.h"

class Assistant {
private:
    Comparator *c;
    Cluster *cl;
    Analyzer *a;
    map<string, Request*> *m;
    static string genTarAlgSh(string&, string&, string&, string&, string&);
    static string genDes(string &id, string &n, string &e) {return id + "  " + n + "  " + e + "\n";}
public:
    Assistant();
    Assistant(const Assistant &s) = delete;
    Assistant& operator=(const Assistant& s) = delete;
    Assistant(Assistant&& s) = delete;
    Assistant& operator=(Assistant&& s) = delete;
    ~Assistant();

    void initRequestConf();
    void initRequestConf(const string);
    void initRequestConf(const char *);
    void printReqConf();
    void genTestCase(unsigned int flag);
    void regNewAlg(string &, string &, string &);
    void update(string &, string &, string &);
    string remove(string &name);
    vector<vector<string> > * loadRegisteredAlg();
    void compare(unsigned int flag = 0);
    vector<vector<string> > * loadAlgOtp(const string &);
    void printComparator() {this->c->print();}
    Analyzer * runAlg(AOT *);
};

#endif //SIMULATORCPP_ASSISTANT_H
