//
// Created by Tongxuan on 2019-05-22.
//

#ifndef SIMULATORCPP_OBJOLD_H
#define SIMULATORCPP_OBJOLD_H

#ifdef __cplusplus
extern "C" {
#endif

struct status {
    // When updating the status map, treat ALL Rem C, G and M as how much the resources requested, not reminding.
    unsigned int timeStart;
    unsigned int timeTerminate;
    unsigned int remC;
    unsigned int remG;
    unsigned int remM;
};

struct mapNode {
    unsigned int time;
    unsigned int cUse;
    unsigned int gUse;
    unsigned int mUse;
};

struct mapConnector {
    struct mapConnector *prev;
    struct mapNode *n;
    struct mapConnector *next;
};

struct statusMap {
    struct mapConnector *head;
    struct mapConnector *tail;
    unsigned int length;
};

struct status * initStatus(unsigned int b, unsigned int t, unsigned int c, unsigned int g, unsigned int m);
void desStatus(struct status *s);
struct mapNode * initMapNode(unsigned int t, unsigned int c, unsigned int g, unsigned int m);
void desMapNode(struct mapNode *nm);
struct statusMap * initStatusMap();
void desStatusMap(struct statusMap *sm);
struct mapConnector * initMapConnector(struct mapNode *mn);
void desMapConn(struct mapConnector *mc);
void statusMapAdd(struct statusMap *sm, struct mapNode *mn);
struct statusMap *sortTimeNode(struct statusMap *sm); //desStatusMap Required as a pair

#ifdef __cplusplus
};
#endif

#endif //SIMULATORCPP_OBJOLD_H
