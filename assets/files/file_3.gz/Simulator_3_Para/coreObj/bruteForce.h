//
// Created by Tongxuan on 2019-05-26.
//

#ifndef SIMULATORCPP_BRUTEFORCE_H
#define SIMULATORCPP_BRUTEFORCE_H

#include <string>
#include <map>
#include "confMap.h"
#include "status.h"
#include "request.h"
#include "analyzer.h"

class BruteForce {
private:
    ConfMap *cm;
    map<string, Request *> *m;
    bool closed;
    char *ID;
public:
    BruteForce(map<string, Request *> *);
    BruteForce(const BruteForce &s);
    BruteForce& operator=(const BruteForce& s);
    BruteForce(BruteForce&& s);
    BruteForce& operator=(BruteForce&& s);
    ~BruteForce();

    Analyzer * exe(Cluster *c);
    void print();
};

#endif //SIMULATORCPP_BRUTEFORCE_H
