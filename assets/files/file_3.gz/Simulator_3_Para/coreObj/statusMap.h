//
// Created by Tongxuan on 2019-05-22.
//

#include <vector>
#include "status.h"
#include "objOld.h"
#include "cluster.h"

#ifndef SIMULATORCPP_STATUSMAP_H
#define SIMULATORCPP_STATUSMAP_H

class StatusMap {
private:
    char *id;
    vector<Status *> *sv;
    bool closed;
    struct statusMap *sm;/*
    bool tsExist(unsigned int);
    void sortStatusEnd();*/
public:
    StatusMap();
    StatusMap(const StatusMap &s);
    StatusMap& operator=(const StatusMap& s);
    StatusMap(StatusMap&& s);
    StatusMap& operator=(StatusMap&& s);
    ~StatusMap();

    void insert(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
    void print(Cluster *c);
    vector<Status *> *getSV() {return this->sv;}
};

Status ** convVecToArr(vector<Status *> *);

#endif //SIMULATORCPP_STATUSMAP_H
