//
// Created by Tongxuan on 2019-05-23.
//

#ifndef SIMULATORCPP_CLUSTER_H
#define SIMULATORCPP_CLUSTER_H

class Cluster {
private:
    unsigned int c;
    unsigned int g;
    unsigned int m;
    bool closed;
public:
    Cluster(unsigned int c = 0, unsigned int g = 0, unsigned int m = 0);
    Cluster(const Cluster &s);
    Cluster& operator=(const Cluster& s);
    Cluster(Cluster&& s);
    Cluster& operator=(Cluster&& s);
    ~Cluster();

    unsigned int getC() {return this->c;}
    unsigned int getG() {return this->g;}
    unsigned int getM() {return this->m;}
    void print();
};

#endif //SIMULATORCPP_CLUSTER_H
