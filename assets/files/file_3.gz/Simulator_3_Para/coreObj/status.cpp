//
// Created by Tongxuan on 2019-05-21.
//

#include <stdio.h>
#include <cstring>
#include "status.h"
#include "../util.h"
#include "objService.h"

Status::Status(unsigned int s, unsigned int l, unsigned int c, unsigned int g, unsigned int m) {
    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, strToChar(genID("ST")));
    this->startTime = s;
    this->jobLength = l;
    this->cUse = c;
    this->gUse = g;
    this->mUse = m;
    this->closed = false;
}

Status::Status(const Status &s) : startTime(0), jobLength(0), cUse(0), gUse(0), mUse(0) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->startTime = s.startTime;
    this->jobLength = s.jobLength;
    this->cUse = s.cUse;
    this->gUse = s.gUse;
    this->mUse = s.mUse;
}

Status &Status::operator=(const Status &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->startTime = s.startTime;
    this->jobLength = s.jobLength;
    this->cUse = s.cUse;
    this->gUse = s.gUse;
    this->mUse = s.mUse;

    return *this;
}

Status::Status(Status &&s) : startTime(0), jobLength(0), cUse(0), gUse(0), mUse(0) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->startTime = s.startTime;
    this->jobLength = s.jobLength;
    this->cUse = s.cUse;
    this->gUse = s.gUse;
    this->mUse = s.mUse;

    delete &s;
}

Status &Status::operator=(Status &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    this->startTime = s.startTime;
    this->jobLength = s.jobLength;
    this->cUse = s.cUse;
    this->gUse = s.gUse;
    this->mUse = s.mUse;

    delete &s;
    return *this;
}

Status::~Status() {
    if (this->closed) return;
    free(this->id);
    this->id = nullptr;
    this->startTime = 0;
    this->jobLength = 0;
    this->cUse = 0;
    this->gUse = 0;
    this->mUse = 0;
    this->closed = true;
}

bool Status::operator==(const Status &s) {
    if (this->closed || s.closed) return false;
    return this->startTime == s.startTime && this->jobLength == s.jobLength && this->cUse == s.cUse &&
           this->gUse == s.gUse && this->mUse == s.mUse;
}

bool Status::operator!=(const Status &s) {
    if (this->closed || s.closed) return false;
    return !(*this == s);
}

void Status::print(Cluster *c) {
    if (this->closed) return ::print("Status closed");
    printf("SID %s, from %4d, until %4d: CPU %3d, GPU %3d, MEM %3d", this->id, this->startTime,
           this->jobLength, this->cUse, this->gUse, this->mUse);

    if (this->cUse == 0 && this->gUse == 0 && this->mUse == 0) printf("\t (Idle)\n");
    else printf("\t (CPU %6.2f%%, GPU %6.2f%%, MEM %6.2f%%, Overall %6.2f%%)\n",
                (float)this->cUse * 100 / c->getC(), (float)this->gUse * 100 / c->getG(), (float)this->mUse * 100 / c->getM(),
                (float)(this->cUse + this->gUse + this->mUse) * 100 / (c->getC() + c->getG() + c->getM()));
}

