//
// Created by Tongxuan on 2019-05-22.
//

#include <stdlib.h>
#include <stdio.h>
#include "objOld.h"

struct status *initStatus(unsigned int b, unsigned int t, unsigned int c, unsigned int g, unsigned int m) {
    struct status *s = malloc(sizeof(struct status));
    s->timeStart = b;
    s->timeTerminate = t;
    s->remC = c;
    s->remG = g;
    s->remM = m;
    return s;
}

void desStatus(struct status *s) {
    s->timeTerminate = 0;
    s->remM = 0;
    s->remG = 0;
    s->remC = 0;
    s->timeStart = 0;
    free(s);
}

struct mapNode *initMapNode(unsigned int t, unsigned int c, unsigned int g, unsigned int m) {
    struct mapNode *mn = malloc(sizeof(struct mapNode));
    mn->time = t;
    mn->cUse = c;
    mn->gUse = g;
    mn->mUse = m;
    return mn;
}

struct mapNode *mapNodeCpy(struct mapNode nm) {
    struct mapNode *mn = malloc(sizeof(struct mapNode));
    mn->time = nm.time;
    mn->cUse = nm.cUse;
    mn->gUse = nm.gUse;
    mn->mUse = nm.mUse;
    return mn;
}

void desMapNode(struct mapNode *nm) {
    nm->cUse = 0;
    nm->time = 0;
    nm->mUse = 0;
    nm->gUse = 0;
    free(nm);
}

struct statusMap *initStatusMap() {
    struct statusMap *sm = malloc(sizeof(struct statusMap));
    sm->length = 0;
    sm->head = NULL;
    sm->tail = NULL;
    return sm;
}

void desStatusMap(struct statusMap *sm) {
    while (sm->head != NULL) {
        struct mapConnector *iter = sm->head->next;
        desMapConn(sm->head);
        sm->head = iter;
    }
    sm->tail = NULL;
    sm->length = 0;
    free(sm);
}

struct mapConnector *initMapConnector(struct mapNode *mn) {
    struct mapConnector *mc = malloc(sizeof(struct mapConnector));
    mc->n = mn;
    mc->next = NULL;
    mc->prev = NULL;
    return mc;
}

void desMapConn(struct mapConnector *mc) {
    desMapNode(mc->n);
    mc->n = NULL;
    mc->next = NULL;
    mc->prev = NULL;
    free(mc);
}

void statusMapAdd(struct statusMap *sm, struct mapNode *mn) {
    struct mapConnector *mc = sm->head;
    while (mc != NULL) {
        if (mc->n->time == mn->time) return;
        mc = mc->next;
    }
    if (sm->length == 0) {
        sm->head = initMapConnector(mapNodeCpy(*mn));
        sm->tail = sm->head;
    } else {
        struct mapConnector *mc2 = initMapConnector(mapNodeCpy(*mn));
        sm->tail->next = mc2;
        mc2->prev = sm->tail;
        sm->tail = mc2;
    }
    sm->length++;
}

struct mapNode **StatusMap2Arr(struct statusMap *sm) {
    struct mapNode **mn = calloc(sm->length, sizeof(struct mapNode *));
    struct mapConnector *mc = sm->head;
    for (int i = 0; i < sm->length; i++) {
        mn[i] = mapNodeCpy(*mc->n);
        mc = mc->next;
    }
    return mn;
}

struct statusMap *MapNodeArr2Map(struct mapNode **mn, unsigned int length) {
    struct statusMap *m = initStatusMap();
    for (int i = 0; i < length; i++) statusMapAdd(m, mn[i]);
    return m;
}

int *mergeOld(const int *ori, unsigned int length, const int *l, unsigned int lStart, unsigned int lEnd, const int *r,
              unsigned int rStart, unsigned int rEnd) {
    int *rtn = calloc(length, sizeof(int));
    int l_ptr = lStart;
    int r_ptr = rStart;
    int rtn_ptr = lStart;

    while (l_ptr <= lEnd && r_ptr <= rEnd && rtn_ptr <= rEnd) {
        if (ori[l[l_ptr]] <= ori[r[r_ptr]]) {
            rtn[rtn_ptr] = l[l_ptr];
            l_ptr++;
        } else {
            rtn[rtn_ptr] = r[r_ptr];
            r_ptr++;
        }
        rtn_ptr++;
    }

    for (int i = l_ptr; i <= lEnd; i++) {
        rtn[rtn_ptr] = l[i];
        rtn_ptr++;
    }

    for (int i = r_ptr; i <= rEnd; i++) {
        rtn[rtn_ptr] = r[i];
        rtn_ptr++;
    }
    return rtn;
}

int *sortCoreOld(int *i, unsigned int length, unsigned int start, unsigned int end) {
    if (end > length || start > end) return NULL;
    int *rtn;
    if (start == end) {
        rtn = calloc(length, sizeof(int));
        rtn[start] = start;
        return rtn;
    }

    int *leftS = sortCoreOld(i, length, start, (start + end) / 2);
    int *rightS = sortCoreOld(i, length, (start + end) / 2 + 1, end);

    rtn = mergeOld(i, length, leftS, start, (start + end) / 2, rightS, (start + end) / 2 + 1, end);
    free(leftS);
    free(rightS);
    return rtn;
}

struct statusMap *sortPublicMap(int *i, struct mapNode **mn, unsigned int length) {
    int *temp = sortCoreOld(i, length, 0, length - 1);
    struct mapNode **rtnA = calloc(length, sizeof(struct mapNode *));
    for (int j = 0; j < length; j++) {
        rtnA[j] = mn[temp[j]];
    }
    free(temp);
    struct statusMap *rtn = MapNodeArr2Map(rtnA, length);
    free(rtnA);
    return rtn;
}

struct statusMap *sortTimeNode(struct statusMap *sm) {
    struct mapNode **mn = StatusMap2Arr(sm);
    int *i = calloc(sm->length, sizeof(struct mapNode));
    for (int j = 0; j < sm->length; j++) {
        i[j] = mn[j]->time;
    }
    struct statusMap *rtn = sortPublicMap(i, mn, sm->length);
    for (unsigned int j = 0; j < sm->length; j++) desMapNode(mn[j]);
    free(mn);
    free(i);
    return rtn;
}

