//
// Created by Tongxuan on 2019-05-22.
//

#ifndef SIMULATORCPP_ALGORITHM_H
#define SIMULATORCPP_ALGORITHM_H

#include <map>
#include <string>
#include "cluster.h"
#include "request.h"

using namespace std;

class Algorithm {
private:
    map<string, int> *m;
    Cluster *c; // External object, DO NOT DELETE
    char *name;
    void printMap();
    bool closed;
public:
    Algorithm(const string &, Cluster *);
    Algorithm(const char *, Cluster *);
    Algorithm(const Algorithm &s);
    Algorithm& operator=(const Algorithm& s);
    Algorithm(Algorithm&& s);
    Algorithm& operator=(Algorithm&& s);
    ~Algorithm();

    void print();
    void setMap(map<string, int> &m) {*(this->m) = m;}
    map<string, int> * getMap() {return this->m;}
    bool validate(map<string, Request*> *m);
    char * getName() {return this->name;}
};

#endif //SIMULATORCPP_ALGORITHM_H
