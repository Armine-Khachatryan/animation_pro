//
// Created by Tongxuan on 2019-05-22.
//

#include <cstring>
#include "analyzer.h"
#include "../util.h"
#include "objService.h"

Analyzer::Analyzer(const string &n, map<string, Request *> *rv, Cluster *c) {
    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, strToChar(n));
    this->rv = rv;
    this->a = new Algorithm(this->name, c);
    this->closed = false;
    this->cm = new ConfMap();
    this->score = 0.0;
    this->c = c;
}

Analyzer::Analyzer(const char *n, map<string, Request *> *rv, Cluster *c) {
    this->name = (char *) calloc(64, sizeof(char));
    if (n != nullptr) strcpy(this->name, n);
    else strcpy(this->name, strToChar(genID("AZ")));
    this->rv = rv;
    this->a = new Algorithm(this->name, c);
    this->closed = false;
    this->cm = new ConfMap();
    this->score = 0.0;
    this->c = c;
}

Analyzer::Analyzer(const Analyzer &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->rv = s.rv;
    this->a = new Algorithm(this->name, this->c);
    *(this->a) = *(s.a);
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->score = s.score;
    this->c = s.c;
}

Analyzer &Analyzer::operator=(const Analyzer &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->rv = s.rv;
    this->a = new Algorithm(this->name, this->c);
    *(this->a) = *(s.a);
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->score = s.score;
    this->c = s.c;

    return *this;
}

Analyzer::Analyzer(Analyzer &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->rv = s.rv;
    this->a = new Algorithm(this->name, this->c);
    *(this->a) = *(s.a);
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->score = s.score;
    this->c = s.c;

    delete &s;
}

Analyzer &Analyzer::operator=(Analyzer &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->rv = s.rv;
    this->a = new Algorithm(this->name, this->c);
    *(this->a) = *(s.a);
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->score = s.score;
    this->c = s.c;

    delete &s;
    return *this;
}

Analyzer::~Analyzer() {
    if (this->closed) return;
    this->score = 0.0;
    this->closed = true;
    delete this->a;
    delete this->cm;
    free(this->name);
    this->name = nullptr;
}

void Analyzer::print() {
    if (this->closed) return ::print("Analyzer Closed");
    this->a->print();
    this->cm->print(this->c);
    ::print("This score: " + to_string(this->score));
}

void Analyzer::setConfMap() {
    if (this->closed) return;
    map<string, int> *algOtp = this->a->getMap();
    for (auto iter = algOtp->begin(); iter != algOtp->end(); iter++) {
        if (this->rv->count(iter->first) == 0) continue;
        Request *r = this->rv->find(iter->first)->second;
        this->cm->insert(iter->second, r->getE(), r->getC(), r->getG(), r->getM());
    }
}

bool Analyzer::validate() {
    if (this->closed) return false;
    return this->cm->validate(this->c) && this->a->validate(this->rv);
}

