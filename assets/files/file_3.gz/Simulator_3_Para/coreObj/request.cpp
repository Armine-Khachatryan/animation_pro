//
// Created by Tongxuan on 2019-05-22.
//

#include <cstring>
#include <stdio.h>
#include "../util.h"
#include "request.h"
#include "objService.h"

Request::Request(const string &n, unsigned pu, unsigned int p, unsigned int c, unsigned int g, unsigned int m,
                 unsigned int e) {
    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, strToChar(n));
    this->pu = pu;
    this->p = p;
    this->c = c;
    this->g = g;
    this->m = m;
    this->e = e;
    this->closed = false;
}

Request::Request(const char *n, unsigned pu, unsigned int p, unsigned int c, unsigned int g, unsigned int m,
                 unsigned int e) {
    this->name = (char *) calloc(64, sizeof(char));
    if (n != nullptr) strcpy(this->name, n);
    else strcpy(this->name, strToChar(genID("RS")));
    this->pu = pu;
    this->p = p;
    this->c = c;
    this->g = g;
    this->m = m;
    this->e = e;
    this->closed = false;
}

Request::Request(const Request &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->pu = s.pu;
    this->p = s.p;
    this->c = s.c;
    this->g = s.g;
    this->m = s.m;
    this->e = s.e;
}

Request &Request::operator=(const Request &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->pu = s.pu;
    this->p = s.p;
    this->c = s.c;
    this->g = s.g;
    this->m = s.m;
    this->e = s.e;

    return *this;
}

Request::Request(Request &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->pu = s.pu;
    this->p = s.p;
    this->c = s.c;
    this->g = s.g;
    this->m = s.m;
    this->e = s.e;

    delete &s;
}

Request &Request::operator=(Request &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->pu = s.pu;
    this->p = s.p;
    this->c = s.c;
    this->g = s.g;
    this->m = s.m;
    this->e = s.e;

    delete &s;
    return *this;
}

Request::~Request() {
    if (this->closed) return;
    free(this->name);
    this->name = nullptr;
    this->pu = 0;
    this->p = 0;
    this->c = 0;
    this->g = 0;
    this->m = 0;
    this->e = 0;
    this->closed = true;
}

void Request::print() {
    if (this->closed) return ::print("Request closed");
    printf("%s: Pushed %4d, Prio %4d, CPU %3d, GPU %3d, MEM %3d, Length %2d.\n", this->name, this->pu, this->p, this->c,
           this->g, this->m, this->e);
}

