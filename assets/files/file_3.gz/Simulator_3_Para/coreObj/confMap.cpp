//
// Created by Tongxuan on 2019-05-22.
//

#include "confMap.h"
#include "../util.h"

ConfMap::ConfMap() {
    this->sv = new vector<Status *>();
    this->sm = new StatusMap();
    this->closed = false;
}

ConfMap::ConfMap(const ConfMap &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->sv = new vector<Status *>();
    *(this->sv) = *(s.sv);
    this->sm = new StatusMap();
    *(this->sm) = *(s.sm);
}

ConfMap &ConfMap::operator=(const ConfMap &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->sv = new vector<Status *>();
    *(this->sv) = *(s.sv);
    this->sm = new StatusMap();
    *(this->sm) = *(s.sm);

    return *this;
}

ConfMap::ConfMap(ConfMap &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->sv = new vector<Status *>();
    *(this->sv) = *(s.sv);
    this->sm = new StatusMap();
    *(this->sm) = *(s.sm);

    delete &s;
}

ConfMap &ConfMap::operator=(ConfMap &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->sv = new vector<Status *>();
    *(this->sv) = *(s.sv);
    this->sm = new StatusMap();
    *(this->sm) = *(s.sm);

    delete &s;
    return *this;
}

ConfMap::~ConfMap() {
    if (this->closed) return;
    delete this->sm;
    this->sm = nullptr;
    for (unsigned int i = 0; i < this->sv->size(); i++) {
        delete (*this->sv)[i];
    } while (this->sv->size() > 0) this->sv->erase(this->sv->begin());
    delete this->sv;
    this->sv = nullptr;
    this->closed = true;
}

void ConfMap::print(Cluster *c) {
    if (this->closed) return ::print("Configure Map closed");
    else this->sm->print(c);
}

void
ConfMap::insert(unsigned int s = 0, unsigned int l = 0, unsigned int c = 0, unsigned int g = 0, unsigned int m = 0) {
    if (this->closed) return;
    this->sv->push_back(new Status(s, l, c, g, m));
    this->sm->insert(s, l, c, g, m);
}

bool ConfMap::validate(Cluster *c) {
    if (this->closed) return false;
    for (auto iter = this->sm->getSV()->begin(); iter != this->sm->getSV()->end(); iter++){
        if ((*iter)->getC() > c->getC() || (*iter)->getG() > c->getG() || (*iter)->getM() > c->getM()){
            return false;
        }
    }
    return true;
}

