//
// Created by Tongxuan on 2019-05-21.
//

#ifndef SIMULATORCPP_COREOBJ_H
#define SIMULATORCPP_COREOBJ_H

#include <string>
#include "cluster.h"

using namespace std;

class Status {
private:
    char* id;
    unsigned int startTime;
    unsigned int jobLength;
    unsigned int cUse;
    unsigned int gUse;
    unsigned int mUse;
    bool closed;
public:
    Status(unsigned int s = 0, unsigned int l = 0, unsigned int c = 0, unsigned int g = 0, unsigned int m = 0);
    Status(const Status &s);
    Status& operator=(const Status& s);
    Status(Status&& s);
    Status& operator=(Status&& s);
    ~Status();
    bool operator==(const Status &);
    bool operator!=(const Status &);
    void print(Cluster *c);
    void setStart(unsigned int ts) {this->startTime = ts;}
    unsigned int getStart() {return this->startTime;}
    unsigned int getEnd() {return this->jobLength;}
    bool isEmpty() {return this->cUse == 0 && this->gUse == 0 && this->mUse == 0;}
    void cpConf(Status *s) {
        this->cUse = s->cUse;
        this->gUse = s->gUse;
        this->mUse = s->mUse;
    }
    void modConfInc(unsigned int c, unsigned int g, unsigned int m) {
        this->cUse += c;
        this->gUse += g;
        this->mUse += m;
    }
    unsigned int getC() {return this->cUse;}
    unsigned int getG() {return this->gUse;}
    unsigned int getM() {return this->mUse;}
};

#endif //SIMULATORCPP_COREOBJ_H
