//
// Created by Tongxuan on 2019-05-22.
//

#include <string>

#ifndef SIMULATORCPP_REQUEST_H
#define SIMULATORCPP_REQUEST_H

using namespace std;

class Request {
private:
    char *name;
    unsigned int p;
    unsigned int pu;
    unsigned int c;
    unsigned int g;
    unsigned int m;
    unsigned int e;
    bool closed;
public:
    Request(const string &, unsigned pu = 0, unsigned int p = 0, unsigned int c = 0, unsigned int g = 0,
            unsigned int m = 0, unsigned int e = 0);

    Request(const char *, unsigned pu = 0, unsigned int p = 0, unsigned int c = 0, unsigned int g = 0,
            unsigned int m = 0, unsigned int e = 0);

    Request(const Request &s);

    Request &operator=(const Request &s);

    Request(Request &&s);

    Request &operator=(Request &&s);

    ~Request();

    void print();

    unsigned int getP() { return this->p; }

    unsigned int getE() { return this->e; }

    unsigned int getC() { return this->c; }

    unsigned int getG() { return this->g; }

    unsigned int getM() { return this->m; }

    char *getID() { return this->name; }

    unsigned int getPu() { return this->pu;}
};

#endif //SIMULATORCPP_REQUEST_H
