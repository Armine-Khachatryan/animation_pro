//
// Created by Tongxuan on 2019-05-22.
//

#include "comparator.h"
#include "../util.h"

Comparator::Comparator(vector<Analyzer *> *a, map<string, Request *> *m, Cluster *c) {
    this->av = a;
    this->m = m;
    this->alterID = ::loadAlterId();
    this->c = c;
    this->closed = false;
}

Comparator::Comparator(const Comparator &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->av = new vector<Analyzer *>();
    *(this->av) = *(s.av);
    this->m = new map<string, Request *>();
    *(this->m) = *m;
    this->alterID = s.alterID;
    this->c = s.c;
}

Comparator &Comparator::operator=(const Comparator &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->av = new vector<Analyzer *>();
    *(this->av) = *(s.av);
    this->m = new map<string, Request *>();
    *(this->m) = *m;
    this->alterID = s.alterID;
    this->c = s.c;

    return *this;
}

Comparator::Comparator(Comparator &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->av = new vector<Analyzer *>();
    *(this->av) = *(s.av);
    this->m = new map<string, Request *>();
    *(this->m) = *m;
    this->alterID = s.alterID;
    this->c = s.c;

    delete &s;
}

Comparator &Comparator::operator=(Comparator &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->av = new vector<Analyzer *>();
    *(this->av) = *(s.av);
    this->m = new map<string, Request *>();
    *(this->m) = *m;
    this->alterID = s.alterID;
    this->c = s.c;

    delete &s;
    return *this;
}

Comparator::~Comparator() {
    if (this->closed) return;
    while (this->av->size() > 0) {
        delete *av->begin();
        this->av->erase(this->av->begin());
    }
    delete this->av;
    this->av = nullptr;

    while (this->alterID->size() > 0) this->alterID->erase(this->alterID->begin());
    delete this->alterID;
    this->alterID = nullptr;
    this->closed = true;
}

void Comparator::print() {
    if (this->closed) return ::print("Comparator closed.");
    this->c->print();
    ::print("Request List:");
    if (this->m->size() > 0) for (auto iter = this->m->begin(); iter != this->m->end(); iter++) iter->second->print();
    else ::print("No request registered");
    if (this->av->size() > 0)
        for (auto iter = this->av->begin(); iter != this->av->end(); iter++) {
            (*iter)->print();
            ::print();
        }
    else ::print("No registered algorithms");
}

Analyzer **Comparator::getAna() {
    Analyzer **rtn = new Analyzer *[this->av->size()];
    for (unsigned int i = 0; i < this->av->size(); i++) rtn[i] = (*this->av)[i];
    return rtn;
}

string Comparator::genRtnMsg(const string str) {
    return "\nWe found " + str + this->getAlgAlterID(strToChar(str)) + " is the best algorithm.";
}

string Comparator::genRtnMsg(char *c) {
    if (c == nullptr) return "Comparator internal Error, please contact us at yibo.guo@ais.cmc.osaka-u.ac.jp";
    return genRtnMsg(charToStr(c));
}

bool dismissInvaldAna(Analyzer *a, string exc = "") {
    if (a == nullptr) return false;
    ::print(charToStr(a->getName()) + exc + ". Registration denied");
    delete a;
    a = nullptr;
    return false;
}

bool Comparator::add(Analyzer *a, unsigned int flag) {
    if (a == nullptr) return dismissInvaldAna(a);
    if (!a->validate()) return dismissInvaldAna(a, ": Algorithm not valid");
    map<string, int> *otpMap = a->getAlg()->getMap();
    if (otpMap->size() != this->m->size()) return dismissInvaldAna(a, ": Invalid output length");
    for (auto iter = this->m->begin(); iter != this->m->begin(); iter++) {
        if (otpMap->count(iter->first) == 0)
            return dismissInvaldAna(a, ": Missing or exists extra request");
    }
    this->insert(a);
    if (!(flag & 0b1000)) ::print(charToStr(a->getName()) + ": Algorithm recognized");
    return true;
}

string Comparator::getAlgAlterID(const char *c) {
    return " (a.k.a. " + this->alterID->find(charToStr(c))->second + ")";
}

const string Comparator::doCompare(unsigned int flag) {
    string rtn = "";

    if (this->av->size() == 0) return "No registered analyzer";
    if (this->av->size() == 1)
        return "Only one valid algorithm " + charToStr((*this->av->begin())->getName()) +
               this->getAlgAlterID((*this->av->begin())->getName()) +
               " exists, comparator terminated.";

    // This for loop is evaluating the algorithm performance on each of those registered job requests
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++) {
        Analyzer **aArr = getAna();
        int *AnaExeArr = new int[this->av->size()];
        for (unsigned int i = 0; i < this->av->size(); i++)
            AnaExeArr[i] = aArr[i]->getAlg()->getMap()->find(
                    iter->first)->second; // find the req running ts in each alg

        // obtain algorithms in order by each request's exe timestamp
        int *AnaExeArr1 = sortCore(AnaExeArr, this->av->size(), 0, this->av->size() - 1);
        delete[] AnaExeArr;
        Analyzer **aArr2 = new Analyzer *[this->av->size()];
        for (unsigned int i = 0; i < this->av->size(); i++) aArr2[i] = aArr[AnaExeArr1[i]];
        delete[] aArr;
        delete[] AnaExeArr1;

        for (unsigned int i = 0; i < this->av->size() - 1; i++) {
            int count = 0;
            for (unsigned j = i + 1; j < this->av->size(); j++)
                if (aArr2[i]->getAlg()->getMap()->find(iter->first)->second <
                    aArr2[j]->getAlg()->getMap()->find(iter->first)->second) {
                    count = this->av->size() - j;
                    break;
                }
            aArr2[i]->scoreMod(count);
        }
        delete[] aArr2;
    }

    // modify algorithm score by system utility performance
    vector<double> *tmpAlgAna = new vector<double>();
    for (auto iter = this->av->begin(); iter != this->av->end(); iter++) {
        unsigned int overC = 0;
        unsigned int overG = 0;
        unsigned int overM = 0;
        vector<Status *> *tmpSV = (*iter)->getConfMap()->getSM()->getSV();
        int nonZeroCount = 0;
        for (auto i = tmpSV->begin(); i != tmpSV->end(); i++) {
            if ((*i)->isEmpty()) continue;
            overC += (*i)->getC();
            overG += (*i)->getG();
            overM += (*i)->getM();
            nonZeroCount++;
        }
        tmpAlgAna->push_back((overC + overG + overM) / (nonZeroCount * 3));
    }
    int *tmpIntArr = new int[this->av->size()];
    for (unsigned int i = 0; i < this->av->size(); i++) {
        tmpIntArr[i] = (int) ((*tmpAlgAna)[i] * 1000);
    }
    int *tmpInt2 = sortCore(tmpIntArr, this->av->size(), 0, this->av->size() - 1);
    delete[] tmpIntArr;
    for (unsigned int i = 1; i < this->av->size(); i++) {
        int score = 0;
        for (unsigned int j = 0; j < i; j++)
            if ((*tmpAlgAna)[tmpInt2[i]] > (*tmpAlgAna)[tmpInt2[j]]) {
                score = j + 1;
            }
        (*this->av)[tmpInt2[i]]->scoreMod((double) score * 2);
    }
    while (tmpAlgAna->size() > 0) {
        auto iter = tmpAlgAna->begin();
        *iter = 0.0;
        tmpAlgAna->erase(iter);
    } delete tmpAlgAna;
    delete[] tmpInt2;

    // modify algorithm score by overall system running time
    int *algFinTime = new int[this->av->size()];
    Analyzer **a = getAna();
    for (unsigned int i = 0; i < this->av->size(); i++)
        algFinTime[i] = (*((a[i]->getConfMap()->getSM()->getSV()->end()) - 1))->getEnd();
    int *tmpIntArr3 = sortCore(algFinTime, this->av->size(), 0, this->av->size() - 1);
    for (unsigned int i = 0; i < this->av->size() - 1; i++) {
        int score = 0;
        for (unsigned int j = i + 1; j < this->av->size(); j++)
            if (algFinTime[tmpIntArr3[i]] < algFinTime[tmpIntArr3[j]]) {
                score = this->av->size() - j;
                break;
            }
        (*this->av)[tmpIntArr3[i]]->scoreMod((double) score);
    }
    delete[] algFinTime;
    delete[] a;
    a = nullptr;
    delete[] tmpIntArr3;

    // Get the final decision
    int *finalSort = new int[this->av->size()];
    for (unsigned int i = 0; i < this->av->size(); i++)
        finalSort[i] = (*this->av)[i]->getScore();
    int *finalRtn = sortCore(finalSort, this->av->size(), 0, this->av->size() - 1);
    delete[] finalSort;
    unsigned int sameRank = 0;
    for (unsigned int i = sameRank; i < this->av->size() - 1; i++)
        if ((*this->av)[finalRtn[sameRank]]->getScore() != (*this->av)[finalRtn[sameRank + 1]]->getScore()) sameRank++;

    if (sameRank == this->av->size() - 1) rtn = genRtnMsg((*this->av)[finalRtn[this->av->size() - 1]]->getName());
    else {
        rtn = "\nWe found algorithm";
        for (unsigned int i = sameRank; i < this->av->size(); i++) {
            if (i == this->av->size() - 1) rtn += " and";
            else if (i != sameRank) rtn += ", ";
            rtn += " " + charToStr((*this->av)[finalRtn[i]]->getName()) +
                   this->getAlgAlterID((*this->av)[finalRtn[i]]->getName());
        }
        rtn += " have the same performance, and they are ";
        if (this->av->size() - sameRank == 2) rtn += "both";
        else rtn += "all";
        rtn += " the best algorithm.";
    }

    string rankPrt = "";
    for (unsigned int i = 0; i < this->av->size(); i++) {
        rankPrt += "Position " + to_string(i + 1) + ": " +
                   charToStr((*this->av)[finalRtn[this->av->size() - i - 1]]->getName())
                   + this->getAlgAlterID((*this->av)[finalRtn[this->av->size() - i - 1]]->getName())
                   + ": " + to_string((*this->av)[finalRtn[this->av->size() - i - 1]]->getScore());
        if (i != this->av->size() - 1) rankPrt += "\n";
    }
    delete[] finalRtn;

    rtn += "\n\n*** This conclusion is only responsible for recognized algorithms and input at this execution. ***";
    rtn += "\n*** We do not guarantee the accuracy if either any of registered algorithms or the input changed. ***";
    rtn += "\n*** In case of anything changed, please re-run this program to get a better advice. ***";

    if (flag & 0b100) ::print("\nAll scores:\n" + rankPrt);
    return rtn;
}

vector<Analyzer *> * Comparator::getAV() {
    return this->av;
}

