//
// Created by Tongxuan on 2019-05-22.
//

#ifndef SIMULATORCPP_CONFMAP_H
#define SIMULATORCPP_CONFMAP_H

#include "statusMap.h"
#include "cluster.h"

class ConfMap{
private:
    StatusMap *sm;
    vector<Status *> *sv;
    bool closed;
public:
    ConfMap();
    ConfMap(const ConfMap &s);
    ConfMap& operator=(const ConfMap& s);
    ConfMap(ConfMap&& s);
    ConfMap& operator=(ConfMap&& s);
    ~ConfMap();

    void print(Cluster *C);
    void insert(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
    bool validate(Cluster *);
    StatusMap * getSM() {return this->sm;}
    vector<Status *> * getSV() {return this->sv;}
};

#endif //SIMULATORCPP_CONFMAP_H
