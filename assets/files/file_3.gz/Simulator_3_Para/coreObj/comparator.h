//
// Created by Tongxuan on 2019-05-22.
//

#ifndef SIMULATORCPP_COMPARATOR_H
#define SIMULATORCPP_COMPARATOR_H

#include <vector>
#include <map>
#include "analyzer.h"
#include "request.h"
#include "cluster.h"
#include "algorithmObj.h"

class Comparator {
private:
    vector<Analyzer *> *av;
    map<string, Request *> *m;
    map<string, string> *alterID;
    Cluster *c;
    bool closed;

    void insert(Analyzer *a) {if(!closed) this->av->push_back(a);}
    string getAlgAlterID(const char *);
    string genRtnMsg(const string str = "N/A");
    string genRtnMsg(char *);
public:
    Comparator(vector<Analyzer *> *, map<string, Request *> *, Cluster *);
    Comparator(const Comparator &s);
    Comparator& operator=(const Comparator& s);
    Comparator(Comparator&& s);
    Comparator& operator=(Comparator&& s);
    ~Comparator();

    void print();
    bool add(Analyzer *, unsigned int);
    const string doCompare(unsigned int flag);
    Analyzer ** getAna();
    vector<Analyzer *> * getAV();
};

#endif //SIMULATORCPP_COMPARATOR_H
