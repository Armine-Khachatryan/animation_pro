//
// Created by Tongxuan on 2019-05-23.
//

#include <stdio.h>
#include "cluster.h"
#include "../util.h"

Cluster::Cluster(unsigned int c, unsigned int g, unsigned int m) {
    this->c = c;
    this->g = g;
    this->m = m;
    this->closed = false;
}

Cluster::Cluster(const Cluster &s){
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->c = s.c;
    this->g = s.g;
    this->m = s.m;
}

Cluster& Cluster::operator=(const Cluster& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->c = s.c;
    this->g = s.g;
    this->m = s.m;

    return *this;
}

Cluster::Cluster(Cluster&& s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->c = s.c;
    this->g = s.g;
    this->m = s.m;

    delete &s;
}
Cluster& Cluster::operator=(Cluster&& s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->c = s.c;
    this->g = s.g;
    this->m = s.m;

    delete &s;
    return *this;
}

Cluster::~Cluster() {
    if (this->closed) return;
    this->closed = true;
    this->c = 0;
    this->g = 0;
    this->m = 0;
}

void Cluster::print() {
    printf("Cluster: CPU %d, GPU %d, MEM %d\n", this->c, this->g, this->m);
}

