//
// Created by Tongxuan on 2019-05-26.
//

#include <cstring>
#include "../util.h"
#include "bruteForce.h"
#include "objService.h"

BruteForce::BruteForce(map<string, Request *> *m) {
    this->m = m;
    this->cm = new ConfMap();
    this->ID = (char *) calloc(64, sizeof(char));
    strcpy(this->ID, strToChar(genID("BF")));
    this->closed = false;
}

BruteForce::BruteForce(const BruteForce &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->m = s.m;
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->ID = (char *) calloc(64, sizeof(char));
    strcpy(this->ID, s.ID);
}

BruteForce &BruteForce::operator=(const BruteForce &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->m = s.m;
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->ID = (char *) calloc(64, sizeof(char));
    strcpy(this->ID, s.ID);

    return *this;
}

BruteForce::BruteForce(BruteForce &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->m = s.m;
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->ID = (char *) calloc(64, sizeof(char));
    strcpy(this->ID, s.ID);

    delete &s;
}

BruteForce &BruteForce::operator=(BruteForce &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->m = s.m;
    this->cm = new ConfMap();
    *(this->cm) = *(s.cm);
    this->ID = (char *) calloc(64, sizeof(char));
    strcpy(this->ID, s.ID);

    delete &s;
    return *this;
}

BruteForce::~BruteForce() {
    if (this->closed) return;
    this->closed = true;
    free(this->ID);
    this->ID = nullptr;
    delete this->cm;
}

bool validBF(vector<Status *> *sv, vector<Status *>::iterator iter, Request *r, Cluster *c, unsigned int startT) {
    unsigned int endT = startT + r->getE();
    auto tmpIter = iter;
    bool flag = true;
    while (flag) {
        if (tmpIter == sv->end()) return true;
        if ((*tmpIter)->getEnd() >= endT) flag = false;
        if ((*tmpIter)->getC() + r->getC() > c->getC()) return false;
        if ((*tmpIter)->getG() + r->getG() > c->getG()) return false;
        if ((*tmpIter)->getM() + r->getM() > c->getM()) return false;
        tmpIter++;
    } return true;
}

unsigned int getFisrtPropBF(unsigned int ets, ConfMap *cm, Request *r, Cluster *c) {
    if (cm->getSM()->getSV()->size() == 0) return r->getPu();
    /*else return (*(cm->getSM()->getSV()->end() - 1))->getEnd() > r->getPu() ?
                (*(cm->getSM()->getSV()->end() - 1))->getEnd() : r->getPu();*/
    unsigned int rtn = ets > r->getPu() ? ets : r->getPu();
    auto iter = cm->getSM()->getSV()->begin();
    while((*iter)->getEnd() <= rtn && iter != cm->getSM()->getSV()->end()) iter ++;
    while (iter != cm->getSM()->getSV()->end() && !validBF(cm->getSM()->getSV(), iter, r, c, rtn)) {
        iter++;
        rtn = (*iter)->getEnd();
    } if (iter == cm->getSM()->getSV()->end()) return (*(iter - 1))->getEnd();
    return rtn;
}

Analyzer *BruteForce::exe(Cluster *c) {
    auto *strMap = new map<string, int>();

    auto **rArr = new Request *[this->m->size()];
    unsigned int i = 0;
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++) {
        rArr[i] = iter->second;
        i++;
    }

    int *iArr = new int[this->m->size()];
    for (i = 0; i < this->m->size(); i++) iArr[i] = rArr[i]->getP();
    int *iRtn = sortCore(iArr, this->m->size(), 0, this->m->size() - 1);
    delete[] iArr;
    iArr = nullptr;
    auto **rArr2 = new Request *[this->m->size()];
    for (unsigned int i = 0;i < this->m->size(); i++) rArr2[i] = rArr[iRtn[i]];
    delete[] rArr;
    rArr = nullptr;
    delete[] iRtn;
    iRtn = nullptr;

    int *iArr2 = new int[this->m->size()];
    for (i = 0; i < this->m->size(); i++) iArr2[i] = rArr2[i]->getPu();
    int *iRtn2 = sortCore(iArr2, this->m->size(), 0, this->m->size() - 1);
    delete[] iArr2;
    iArr2 = nullptr;
    auto **rArr3 = new Request *[this->m->size()];
    for (unsigned int i = 0;i < this->m->size(); i++) rArr3[i] = rArr2[iRtn2[i]];
    delete[] rArr2;
    rArr2 = nullptr;
    delete[] iRtn2;
    iRtn2 = nullptr;

    unsigned int ets = 0;
    for (i = 0; i < this->m->size(); i++) {
        ets = getFisrtPropBF(ets, this->cm, rArr3[i], c);
        strMap->insert(make_pair(rArr3[i]->getID(), ets));
        this->cm->insert(ets, rArr3[i]->getE(), rArr3[i]->getC(), rArr3[i]->getG(),
                         rArr3[i]->getM());
    }

    Analyzer *a = new Analyzer("BRUTE_FORCE", this->m, c);
    a->getAlg()->setMap(*strMap);
    a->setConfMap();
    delete strMap;
    strMap = nullptr;
    delete[] rArr2;
    rArr2 = nullptr;
    delete[] rArr3;
    rArr3 = nullptr;
    return a;
}

void BruteForce::print() {
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++) { iter->second->print(); }
}

