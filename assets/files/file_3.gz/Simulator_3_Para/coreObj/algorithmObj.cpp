//
// Created by Tongxuan on 2019-05-22.
//

#include <cstring>
#include <stdio.h>
#include "../util.h"
#include "algorithmObj.h"
#include "objService.h"

Algorithm::Algorithm(const string &n, Cluster *c) {
    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, strToChar(n));
    this->m = new map<string, int>;
    this->closed = false;
    this->c = c;
}

Algorithm::Algorithm(const char *n, Cluster *c) {
    this->name = (char *) calloc(64, sizeof(char));
    if (n != nullptr) strcpy(this->name, n);
    else (strcpy(this->name, strToChar(genID("AG"))));
    this->m = new map<string, int>;
    this->closed = false;
    this->c = c;
}

Algorithm::Algorithm(const Algorithm &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->m = new map<string, int>;
    *(this->m) = *(s.m);
    this->c = s.c;
}

Algorithm &Algorithm::operator=(const Algorithm &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->m = new map<string, int>;
    *(this->m) = *(s.m);
    this->c = s.c;

    return *this;
}

Algorithm::Algorithm(Algorithm &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->m = new map<string, int>;
    *(this->m) = *(s.m);
    this->c = s.c;

    delete &s;
}

Algorithm &Algorithm::operator=(Algorithm &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->name = (char *) calloc(64, sizeof(char));
    strcpy(this->name, s.name);
    this->m = new map<string, int>;
    *(this->m) = *(s.m);
    this->c = s.c;

    delete &s;
    return *this;
}

Algorithm::~Algorithm() {
    if (this->closed) return;
    free(this->name);
    this->name = nullptr;
    while (this->m->size() > 0) this->m->erase(this->m->begin());
    delete this->m;
    this->m = nullptr;
    this->closed = true;
}

void Algorithm::printMap() {
    if (this->closed) return;
    if (this->m->size() == 0) {
        ::print("Empty map");
        return;
    }
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++)
        printf("RID %s Exe Timestamp %d\n", strToChar(iter->first), iter->second);
}

void Algorithm::print() {
    if (this->closed) return ::print("Algorithm closed.");
    ::print("Algorithm " + charToStr(this->name));
    this->printMap();
}

bool Algorithm::validate(map<string, Request *> *m) {
    if (this->m->size() != this->m->size()) return false;
    for (auto iter = m->begin(); iter != m->end(); iter++)
        if (this->m->count(iter->first) == 0) return false;
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++)
        if (iter->second < (signed)m->find(iter->first)->second->getPu()) return false;
    return true;
}

