//
// Created by Tongxuan on 2019-05-22.
//

#include <string>

#ifndef SIMULATORCPP_OBJSERVICE_H
#define SIMULATORCPP_OBJSERVICE_H

using namespace std;

string genID(const string code);

#endif //SIMULATORCPP_OBJSERVICE_H
