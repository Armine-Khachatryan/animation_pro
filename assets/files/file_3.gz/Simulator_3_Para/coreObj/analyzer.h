//
// Created by Tongxuan on 2019-05-22.
//

#ifndef SIMULATORCPP_ANALYZER_H
#define SIMULATORCPP_ANALYZER_H

#include "algorithmObj.h"
#include "confMap.h"
#include "request.h"
#include "cluster.h"

class Analyzer {
private:
    Algorithm *a;
    ConfMap *cm;
    map<string, Request *> *rv;
    Cluster *c;
    bool closed;
    char *name;
    double score;
public:
    Analyzer(const string &, map<string, Request*> *, Cluster *);
    Analyzer(const char *, map<string, Request*> *, Cluster *);
    Analyzer(const Analyzer &s);
    Analyzer& operator=(const Analyzer& s);
    Analyzer(Analyzer&& s);
    Analyzer& operator=(Analyzer&& s);
    ~Analyzer();

    void print();
    Algorithm * getAlg() {return this->a;}
    void setConfMap();
    ConfMap *getConfMap() {return this->cm;}
    char * getName() {return this->name;}
    bool validate();
    void scoreMod(double d) {this->score += d;}
    double getScore() {return this->score;}
};

#endif //SIMULATORCPP_ANALYZER_H
