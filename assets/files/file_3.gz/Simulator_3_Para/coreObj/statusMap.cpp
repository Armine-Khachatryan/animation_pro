//
// Created by Tongxuan on 2019-05-22.
//

#include <cstring>
#include "statusMap.h"
#include "status.h"
#include "objOld.h"
#include "../util.h"
#include "objService.h"

StatusMap::StatusMap() {
    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, strToChar(genID("SM")));
    this->sm = initStatusMap();
    this->sv = new vector<Status *>();
    this->closed = false;
}

StatusMap::StatusMap(const StatusMap &s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) return;

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    free(this->sm);
    this->sm = initStatusMap();
    *(this->sm) = *(s.sm);
    this->sv = new vector<Status *>();
    *(this->sv) = *s.sv;
}

StatusMap &StatusMap::operator=(const StatusMap &s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) return *this;

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    free(this->sm);
    this->sm = initStatusMap();
    *(this->sm) = *(s.sm);
    this->sv = new vector<Status *>();
    *(this->sv) = *s.sv;

    return *this;
}

StatusMap::StatusMap(StatusMap &&s) {
    if (&s == this) return;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return;
    }

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    free(this->sm);
    this->sm = initStatusMap();
    *(this->sm) = *(s.sm);
    this->sv = new vector<Status *>();
    *(this->sv) = *s.sv;

    delete &s;
}

StatusMap &StatusMap::operator=(StatusMap &&s) {
    if (&s == this) return *this;
    this->closed = s.closed;
    if (s.closed) {
        delete &s;
        return *this;
    }

    this->id = (char *) calloc(64, sizeof(char));
    strcpy(this->id, s.id);
    free(this->sm);
    this->sm = initStatusMap();
    *(this->sm) = *(s.sm);
    this->sv = new vector<Status *>();
    *(this->sv) = *s.sv;

    delete &s;
    return *this;
}

StatusMap::~StatusMap() {
    if (this->closed) return;
    free(this->id);
    this->id = nullptr;
    for (unsigned int i = 0; i < this->sv->size(); i++) {
        delete (*this->sv)[i];
    } while (this->sv->size() > 0) this->sv->erase(this->sv->begin());
    delete this->sv;
    this->sv = nullptr;
    desStatusMap(this->sm);
    this->sm = nullptr;
    this->closed = true;
}
/*
bool StatusMap::tsExist(unsigned int t) {
    if (this->closed) return false;
    for (auto i = this->sv->begin(); i != this->sv->end(); i++) {
        Status *s = *i;
        if (s->getEnd() == t) return true;
    }
    return false;
}*/

void setPropConf(vector<Status *> *sv, Status *s) {
    if (sv == nullptr ||s == nullptr || sv->size() == 0) return;
    if (s->getEnd() > (*(sv->end() - 1))->getEnd()) return;
    for (auto iter = sv->begin(); iter != sv->end(); iter++) {
        if (s->getEnd() > (*iter)->getEnd()) s->cpConf((*iter));
        else return;
    }
}

struct mapNode *getProperNode(struct statusMap *sm, unsigned int time) {
    struct mapNode *rtn = initMapNode(time, 0, 0, 0);
    if (sm == nullptr || sm->length == 0) return rtn;
    struct mapConnector *mc = sm->tail;
    int i = 0;
    while (mc != nullptr) {
        if (mc->n->time > time) {
            rtn->cUse = mc->n->cUse;
            rtn->gUse = mc->n->gUse;
            rtn->mUse = mc->n->mUse;
        } else if (mc->n->time == time) {
            *rtn = *(mc->n);
            break;
        } else break;
        mc = mc->prev;
        i++;
    }
    return rtn;
}

void
StatusMap::insert(unsigned int s = 0, unsigned int l = 0, unsigned int c = 0, unsigned int g = 0, unsigned int m = 0) {
    if (this->closed) return;

    struct status *stt = initStatus(s, s + l, c, g, m);
    struct mapNode *mnS = getProperNode(this->sm, stt->timeStart);
    statusMapAdd(this->sm, mnS);
    desMapNode(mnS);
    auto sorted = sortTimeNode(this->sm);
    desStatusMap(this->sm);
    this->sm = sorted;

    struct mapNode *mnE = getProperNode(this->sm, stt->timeTerminate);
    statusMapAdd(this->sm, mnE);
    desMapNode(mnE);
    sorted = sortTimeNode(this->sm);
    desStatusMap(this->sm);
    this->sm = sorted;

    struct mapConnector *mc = this->sm->head;
    while (mc != nullptr) {
        if (mc->n->time > stt->timeStart && mc->n->time <= stt->timeTerminate) {
            mc->n->cUse += stt->remC;
            mc->n->gUse += stt->remG;
            mc->n->mUse += stt->remM;
        } else if (mc->n->time > stt->timeTerminate) break;
        mc = mc->next;
    }

    for (unsigned int i = 0; i < this->sv->size(); i++) {
        delete (*this->sv)[i];
    } while (this->sv->size() > 0) this->sv->erase(this->sv->begin());
    delete this->sv;
    this->sv = new vector<Status *>();

    // leak happens below here
    for (auto iter = this->sm->head; iter != nullptr; iter = iter->next)
        this->sv->push_back(new Status(0, iter->n->time, iter->n->cUse, iter->n->gUse, iter->n->mUse));

    for (auto iter = this->sv->begin() + 1; iter != this->sv->end(); iter++) (*iter)->setStart((*(iter - 1))->getEnd());
    Status *sTmp = *this->sv->begin();
    this->sv->erase(this->sv->begin());
    delete sTmp;

    desStatus(stt);
}

void StatusMap::print(Cluster *c) {
    if (this->closed) ::print("Status Map closed");
    ::print("StatusMap " + charToStr(this->id));
    if (this->sv->size() > 0) {
        for (auto i = this->sv->begin(); i != this->sv->end(); i++) (*i)->print(c);
        printf("The computer will be free in %3d minute(s)\n", (*(this->sv->end() - 1))->getEnd());
    }
    else ::print("Container has no content.");
}

Status **convVecToArr(vector<Status *> *sv) {
    Status **rtn = new Status *[sv->size()];
    for (unsigned int i = 0; i < sv->size(); i++) rtn[i] = (*sv)[i];
    return rtn;
}
/*
int *exSttEnd(Status **s, unsigned int length) {
    if (s == nullptr) return nullptr;
    int *i = new int[length];
    for (unsigned int j = 0; j < length; j++) i[j] = s[j]->getEnd();
    return i;
}

void StatusMap::sortStatusEnd() {
    if (this->closed) return;

    if (this->sv->size() == 0) return;
    Status **sttArr = convVecToArr(this->sv);
    int *intArr = exSttEnd(sttArr, this->sv->size());
    int *sorted = sortCore(intArr, this->sv->size(), 0, this->sv->size() - 1);
    delete[] intArr;
    delete[] sttArr;
    sttArr = new Status *[this->sv->size()];
    for (unsigned int i = 0; i < this->sv->size(); i++) sttArr[i] = (*this->sv)[sorted[i]];
    unsigned int length = this->sv->size();
    delete[] sorted;
    while(this->sv->size() > 0) {
        auto iter = this->sv->begin();
        this->sv->erase(iter);
        delete *iter;
    }
    delete this->sv;
    this->sv = new vector<Status *>();
    for (unsigned int i = 0; i < length; i++) this->insert(sttArr[i]);
    delete[] sttArr;
}*/

