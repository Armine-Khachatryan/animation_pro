//
// Created by Tongxuan on 2019-05-24.
//

#ifndef SIMULATORCPP_SIMULATOR_H
#define SIMULATORCPP_SIMULATOR_H

#include "util.h"

string printList();
string surprise();
string genHelpMsg();
string add(int, char **);
void compare(unsigned int);
string update(int, char **);
string illegalCmd(int, const string &);
string remove(char *);
string reset();
void genTestCase(int, char **);
string genEvalPY();

#endif //SIMULATORCPP_SIMULATOR_H
