//
// Created by Tongxuan on 2019-05-21.
//

#ifndef SIMULATORCPP_UTIL_H
#define SIMULATORCPP_UTIL_H

#include <string>
#include <iostream>
#include <map>
#include <vector>

using namespace std;

void print(const string &);
void print(const char *);
void print(int);
void print(unsigned int);
void print(long long int);
void print(size_t);
void print(double);
void print(bool);
void print(vector<vector<string> > *);
void print();
string charToStr(const char *);
const char * strToChar(const string &);
string getCurrTime(const char *);
string toUpper(string);
long long int getUnixTime();
unsigned int getNanoLastFourHex();
string convIntToHexStr(int);
vector<vector<string> > * loadRegAlg(); // delete required
map<string, string> * loadAlterId(); // delete required, map

int * sortCore(int *, unsigned int, unsigned int, unsigned int); // delete[] required, both para and rtn

string runShell(const char *);
string runShell(const string &);
string runSh(string&);

void mkdir(const string &);
void touch(const string &);
void writeFile(const char *, string, const char *, const char *);
void writeFile(const string &, const string &);
void updateFile(const string &, const string &);
bool dirExist(const string&);
bool fileExist(const char *);
bool fileExist(const string &);
string readFile(const char *);
void rmFile(const char *);
void mv(const string &, const string &);

string genTarAlgSh(string&, string&, string&, string&, string&);
string hexToStr(int);
bool isValidUnNum(const string&);
unsigned int stringToUnNum(const string);
vector<string> split(const string &, const string &);
bool validate(string &, string &, string &, const string &);
bool contains(const string &, const string &);

#endif //SIMULATORCPP_UTIL_H
