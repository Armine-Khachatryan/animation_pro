//
// Created by Tongxuan on 2019-05-24.
//

#include <thread>
#include <mutex>
#include "util.h"
#include "assistant.h"
#include "coreObj/objService.h"
#include "coreObj/bruteForce.h"
#include "service/att.h"
#include "service/aot.h"

Assistant::Assistant() {
    this->c = nullptr;
    this->cl = nullptr;
    this->a = nullptr;
    this->m = nullptr;
}

Assistant::~Assistant() {
    if (this->a != nullptr) delete this->a;
    if (this->m != nullptr) {
        while (this->m->size() > 0) {
            auto iter = this->m->begin();
            delete iter->second;
            iter->second = nullptr;
            this->m->erase(iter);
        }
        delete this->m;
        this->m = nullptr;
    }
    if (this->c != nullptr) delete this->c;
    this->c = nullptr;
    if (this->cl != nullptr) delete this->cl;
    this->cl = nullptr;
    if (fileExist(".algorithm/request.conf")) rmFile(strToChar(".algorithm/request.conf"));
}

void Assistant::initRequestConf() {
    return print("Configuration path required as parameter");
}

void Assistant::initRequestConf(const string tarDir) {
    return this->initRequestConf(strToChar(tarDir));
}

void Assistant::initRequestConf(const char *c) {
    if (!fileExist(c)) return print("Invalid file address");
    if (this->cl != nullptr) {
        delete this->cl;
        this->cl = nullptr;
    }
    if (this->m != nullptr) {
        while (this->m->size() > 0) {
            auto iter = this->m->begin();
            delete iter->second;
            iter->second = nullptr;
            this->m->erase(iter);
        } delete this->m;
        this->m = nullptr;
    }
    string content = readFile(strToChar(c));
    vector<string> reqLoad = split(content, "\n");
    if (reqLoad.size() < 2) return print("Invalid request list");
    for (unsigned int i = 0; i < reqLoad.size(); i++) {
        if (i == 0 && split(reqLoad[i], " ").size() != 3) return print("Cluster syntax error.");
        if (i != 0 && split(reqLoad[i], " ").size() != 7) return print("Request syntax error.");
    } auto clusterVec = split(reqLoad[0], " ");
    this->cl = new Cluster(stringToUnNum(clusterVec[0]), stringToUnNum(clusterVec[1]), stringToUnNum(clusterVec[2]));
    this->m = new map<string, Request *>;
    for (unsigned int i = 1; i < reqLoad.size(); i++) {
        auto reqVec = split(reqLoad[i], " ");
        string id = reqVec[0];
        Request *r = new Request(id, stringToUnNum(reqVec[1]), stringToUnNum(reqVec[2]), stringToUnNum(reqVec[3]), stringToUnNum(reqVec[4]), stringToUnNum(reqVec[5]), stringToUnNum(reqVec[6]));
        this->m->insert(make_pair(id, r));
    }
}

void Assistant::printReqConf() {
    if (this->m == nullptr) return print("Request map not initialed");
    if (this->cl == nullptr) return print("Cluster configuration not initialed");
    this->cl->print();
    for (auto iter = this->m->begin(); iter != this->m->end(); iter++) iter->second->print();
}

void Assistant::genTestCase(unsigned int flag) {
    if (!dirExist(".algorithm")) runShell("mkdir .algorithm");
    srand((unsigned)time(nullptr));
    string rtn = "CPU GPU MEM\n";
    string src = to_string((rand() % 0x11)+ 0x50);
    rtn += src + " " + src + " " + src + "\n";
    int loop = (rand() % (0x40 - 0x30 + 1))+ 0x60;
    int cH = loop * 0.3;
    int gH = loop * 0.2;
    int mH = loop - cH - gH;

    for (int i = 0; i < cH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1))+ 0x0);
        rtn += genID("RC") + " " + push + " " +  prio + " " + exe + " " + maxS + " " + minS + " " + minS + "\n";
    }
    for (int i = 0; i < gH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1))+ 0x0);
        rtn += genID("RP") + " " + push + " "  + prio + " " + exe + " " + minS + " " + maxS + " " + minS + "\n";
    }
    for (int i = 0; i < mH; i++) {
        string prio = to_string((rand() % 0x21) + 0x0);
        string maxS = to_string((rand() % 0x11) + 0x40);
        string minS = to_string((rand() % 0x5) + 0x1);
        string exe = to_string((rand() % 0xF) + 0xA);
        string code = "";
        if (i < 10) code = "00" + to_string(i);
        else if (i < 100) code = "0" + to_string(i);
        else code = to_string(i).substr(0, 3);
        string push = to_string((rand() % (0x40 - 0x0 + 1))+ 0x0);
        rtn += genID("RM") + " " + push + " "  + prio + " " + exe + " " + minS + " " + minS + " " + maxS + "\n";
    }
    string tar = "request.conf";
    string tarAdd = ".algorithm";
    string mode = "w";
    writeFile(rtn.c_str(), tarAdd, tar.c_str(), mode.c_str());
    if (!(flag & 0b1000)) ::print("Test case been generated automatically");
}

string Assistant::genTarAlgSh(string& tarAdd, string& tarExe, string& genAdd, string& genTar, string& genExe) {
    return ::genTarAlgSh(tarAdd, tarExe, genAdd, genTar, genExe);
}

void Assistant::regNewAlg(string &n, string &r, string &e) {
    string nOri = n;
    string eOri = e;
    if (!validate(n, r, e, "a")) return print("Illegal target or target exists.");

    string dir = ".algorithm";
    string cmd;
    if (!dirExist(dir)) {
        cmd = "mkdir " + dir;
        runShell(cmd.c_str());
    }
    cmd = "cp -r " + r.substr(0, r.length() - 1) + " .algorithm/" + n;
    runShell(cmd.c_str());
    string base = ".algorithm/";
    string genExe = n + ".sh";
    string genR = "./" + n;
    genTarAlgSh(n, e, base, genExe, genR);

    string mode = "w";
    string tar = "algorithm.conf";
    string id = genID("AG");
    string cont = readFile(".algorithm/algorithm.conf") + genDes(id, nOri, eOri);

    writeFile(cont.c_str(), ".algorithm", tar.c_str(), mode.c_str());
}

void Assistant::update(string &name, string &root, string &exe) {
    if (validate(name, root, exe, "u") == false) return print("Cannot locate new executable file.\nUpdate completed.");
    if (remove(name) == "Removed.") {
        this->regNewAlg(name, root, exe);
        return print("Update completed.");
    }
    else return print("Target not found, use -a flag.\nUpdate completed.");
}

string Assistant::remove(string &name) {
    string rtn = "";
    bool flag = false;
    vector<vector<string> > * rtnVec = loadRegisteredAlg();
    for (unsigned int i = 0; i < rtnVec->size(); i++) {
        if ((*rtnVec)[i][1] == name) {
            string cmd = "";
            cmd = "rm -rf .algorithm/" + name + "*";
            runShell(cmd.c_str());
            flag = true;
            continue;
        }
        rtn += (*rtnVec)[i][0] + "  " + (*rtnVec)[i][1] + "  " + (*rtnVec)[i][2] + "\n";
    } delete rtnVec;
    if(flag) {
        string dir = ".algorithm";
        string tar = "algorithm.conf";
        string mode = "w";
        writeFile(rtn.c_str(), dir, tar.c_str(), mode.c_str());
        rtn = "Removed.";
        print(rtn);
        return rtn;
    }
    else {
        rtn = "Target not found.\nRemove completed.";
        print(rtn);
        return rtn;
    }
}

vector<vector<string> > * Assistant::loadRegisteredAlg() {
    return ::loadRegAlg();
}

ATT * genATT(const string& i, const string& n) {
    return new ATT(strToChar(i), strToChar(n));
}

ATT * genATT(const char *i, const char *n) {
    return new ATT(i, n);
}

AOT * genAOT(const string &i, const string &c) {
    return new AOT(strToChar(i), strToChar(c));
}

AOT * genAOT(const char *i, const char *c) {
    return new AOT(i, c);
}

vector<AOT *> aotVec;

AOT * collectAlgOtp(ATT *a) {
    return genAOT(a->getID(), runShell(".algorithm/" + charToStr(a->getName()) + ".sh"));
}

mutex *mtx;

void threadRunnable(void *a) {
    lock_guard<std::mutex> lockGuard(*mtx);
    AOT *rtn = collectAlgOtp((ATT *) a);
    aotVec.push_back(rtn);
    delete (ATT *) a;
}

void Assistant::compare(unsigned int flag) {
    string finalTimeAna = "";
    long long int startTime = getUnixTime();
    long long int baseTime = getUnixTime();
    if (!fileExist(".algorithm/request.conf")) this->genTestCase(flag);
    if (this->cl == nullptr || this->m == nullptr) {
        this->initRequestConf(".algorithm/request.conf");
        if (this->cl == nullptr || this->m == nullptr) return;
    } this->c = new Comparator(new vector<Analyzer*>, this->m, this->cl);
    vector<vector<string> > * regAlg = loadRegisteredAlg();
    if (regAlg->size() == 0) return ::print("No registered algorithm");
    if (flag & 0b10) finalTimeAna += "Input conf process used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";

    baseTime = getUnixTime();
    if (!(flag & 0b1000)) ::print("Loading algorithms");
    thread *threads[regAlg->size()];
    mtx = new mutex();
    for (unsigned int i = 0; i < regAlg->size(); i++) {
        threads[i] = new thread(threadRunnable, (void *) genATT((*regAlg)[i][0], (*regAlg)[i][1]));
    } if (!(flag & 0b1000)) ::print("Algorithms loaded into container");

    for (auto &thread : threads) thread->join();
    delete mtx;
    mtx = nullptr;
    if (!(flag & 0b1000)) ::print("Algorithms execution finished\n");
    for (auto &thread : threads) {
        delete thread;
        thread = nullptr;
    }
    for (auto iter = aotVec.begin(); iter != aotVec.end(); iter++) {
        this->c->add(runAlg(*iter), flag);
    }

    for (unsigned int i = 0; i < aotVec.size(); i++) delete aotVec[i];
    while(aotVec.size() > 0) aotVec.erase(aotVec.begin());
    if (flag & 0b10) finalTimeAna += "Algorithms process used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";

    baseTime = getUnixTime();
    BruteForce *bc = new BruteForce(this->m);
    this->c->add(bc->exe(this->cl), flag);
    if (flag & 0b10) finalTimeAna += "Brute force algorithm process used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";

    baseTime = getUnixTime();
    if (!(flag & 0b1000)) ::print(c->doCompare(flag));
    if (flag & 0b10) finalTimeAna += "Comparison used " + to_string((double)(getUnixTime() - baseTime) / 1000000) + " seconds\n";
    if (flag & 0b01) c->print();
    if (flag & 0b1000) {
        c->doCompare(0);
        string tmpOtpDir = "/tmp/ASR";
        string currPID = genID("PR");

        //C, G, M, R, U, F. Each contains all data for all algorithms, spaced with \t
        string algStrArr[6] = {"", "", "", "", "", ""};
        vector<Analyzer *> * cAV = c->getAV();
        string title = "";
        string score = "";
        for (unsigned int i = 0; i < cAV->size(); i++) {
            title += charToStr((*cAV)[i]->getName());
            score += to_string((*cAV)[i]->getScore());
            if (i == cAV->size() - 1) {
                title += "\n";
                score += "\n";
            } else {
                title += "\t";
                score += "\t";
            }
        }
        if (!fileExist(tmpOtpDir + "/util_c.txt")) {
            touch(tmpOtpDir + "/util_c.txt");
            updateFile(title, tmpOtpDir + "/util_c.txt");
        } if (!fileExist(tmpOtpDir + "/util_g.txt")) {
            touch(tmpOtpDir + "/util_g.txt");
            updateFile(title, tmpOtpDir + "/util_g.txt");
        } if (!fileExist(tmpOtpDir + "/util_m.txt")) {
            touch(tmpOtpDir + "/util_m.txt");
            updateFile(title, tmpOtpDir + "/util_m.txt");
        } if (!fileExist(tmpOtpDir + "/r.txt")) {
            touch(tmpOtpDir + "/r.txt");
            updateFile(title, tmpOtpDir + "/r.txt");
        } if (!fileExist(tmpOtpDir + "/util_comprehensive.txt")) {
            touch(tmpOtpDir + "/util_comprehensive.txt");
            updateFile(title, tmpOtpDir + "/util_comprehensive.txt");
        } if (!fileExist(tmpOtpDir + "/finT.txt")) {
            touch(tmpOtpDir + "/finT.txt");
            updateFile(title, tmpOtpDir + "/finT.txt");
        }

        algStrArr[3] += score;

        for (unsigned int i = 0; i < cAV->size(); i++) {
            auto titleSeq = split(*split(readFile(strToChar(tmpOtpDir + "/util_c.txt")), "\n").begin(), "\t");
            unsigned int tarSeq = 0;
            while ((*cAV)[i]->getName() != (titleSeq)[tarSeq] && tarSeq < cAV->size()) tarSeq++;

            vector<Status *> *algSV = (*cAV)[tarSeq]->getConfMap()->getSM()->getSV();
            double C = 0.0, G = 0.0, M = 0.0;
            for (unsigned int j = 0; j < algSV->size(); j++) {
                C += (((double)(*algSV)[j]->getC() / this->cl->getC()) * 100);
                G += (((double)(*algSV)[j]->getG() / this->cl->getG()) * 100);
                M += (((double)(*algSV)[j]->getM() / this->cl->getM()) * 100);
            } algStrArr[0] += to_string(C / algSV->size());
            algStrArr[1] += to_string(G / algSV->size());
            algStrArr[2] += to_string(M / algSV->size());
            algStrArr[4] += to_string((C + G + M) / (3 * algSV->size()));
            algStrArr[5] += to_string((*algSV)[algSV->size() - 1]->getEnd());
            if (i == cAV->size() - 1) {
                algStrArr[0] += "\n";
                algStrArr[1] += "\n";
                algStrArr[2] += "\n";
                algStrArr[4] += "\n";
                algStrArr[5] += "\n";
            } else {
                algStrArr[0] += "\t";
                algStrArr[1] += "\t";
                algStrArr[2] += "\t";
                algStrArr[4] += "\t";
                algStrArr[5] += "\t";
            }
        }
        updateFile(algStrArr[0], tmpOtpDir + "/util_c.txt");
        updateFile(algStrArr[1], tmpOtpDir + "/util_g.txt");
        updateFile(algStrArr[2], tmpOtpDir + "/util_m.txt");
        updateFile(algStrArr[3], tmpOtpDir + "/r.txt");
        updateFile(algStrArr[4], tmpOtpDir + "/util_comprehensive.txt");
        updateFile(algStrArr[5], tmpOtpDir + "/finT.txt");
    }
    delete c;
    this->c = nullptr;
    delete bc;
    bc = nullptr;
    delete regAlg;
    regAlg = nullptr;
    delete this->cl;
    this->cl = nullptr;
    if (flag & 0b10) {
        finalTimeAna += "Function terminating, in total " + to_string((double)(getUnixTime() - startTime) / 1000000) + " seconds\n";
        ::print("\n" + finalTimeAna);
    }
}

Analyzer * Assistant::runAlg(AOT *aot) {
    string algRtn = aot->getContent();
    const string id = aot->getID();
    vector<vector<string> > * algOtp = this->loadAlgOtp(algRtn);
    map<string, int> *algOtpMap = new map<string, int>();
    for (auto iter = algOtp->begin(); iter != algOtp->end(); iter++) {
        algOtpMap->insert(make_pair((*iter)[0], stringToUnNum((*iter)[1])));
    }
    Analyzer *a = new Analyzer(id, this->m, this->cl);
    a->getAlg()->setMap(*algOtpMap);
    a->setConfMap();
    delete algOtp;
    delete algOtpMap;
    return a;
}

vector<vector<string> > * Assistant::loadAlgOtp(const string &str) {
    vector<string> inter = split(str, "\n");
    vector<vector<string> > *rtn = new vector<vector<string> >();
    for (auto iter = inter.begin(); iter != inter.end(); iter++){
        rtn->push_back(split((*iter), " "));
    }
    return rtn;
}

