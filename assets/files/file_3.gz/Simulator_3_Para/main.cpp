//
// Created by Tongxuan on 2019-05-26.
//

#include <cstdlib>
#include "util.h"
#include "simulator.h"
#include "coreObj/objService.h"

int main(int argc, char **argv) {
    if (argc == 1) print(genHelpMsg());
    else if (argc >= 2) {
        string flag(argv[1]);
        if (flag == "-h" || flag == "--help") {
            print(genHelpMsg());
        } else if (flag == "-l" || flag == "--list") {
            print(printList());
        } else if (flag == "-b" || flag == "--bonus") {
            print(surprise());
        } else if (flag == "-a" || flag == "--add") {
            print(add(argc, argv));
        } else if (flag == "-c" || flag == "--compare") {
            unsigned int para = 0;
            for (auto i = 2; i < argc; i++) {
                string flag2(argv[i]);
                if (contains(flag2, "--file=") || contains(flag2, "-f=")) {
                    auto fileConf = split(flag2, "=");
                    if (fileConf.size() != 2) {
                        ::print("Invalid file argument");
                        continue;
                    }
                    if (fileExist(fileConf[1].c_str()) != false) {
                        if (!dirExist(".algorithm")) runShell("mkdir .algorithm");
                        runShell("cp " + fileConf[1] + " .algorithm/request.conf");
                    }
                    continue;
                }
                if (contains(flag2, "--conf=")) {
                    auto fileConf = split(flag2, "=");
                    if (fileConf.size() != 2 || !isValidUnNum(fileConf[1])) {
                        ::print("Invalid rapid configuration ");
                        continue;
                    } else {
                        para = stringToUnNum(fileConf[1]);
                        break;
                    }
                } // Flag conf rtd, as binary
                if ((flag2 == "-d" || flag2 == "--detail") && !(para & 0b1)) para += 0b1;
                if ((flag2 == "-t" || flag2 == "--time") && !(para & 0b10)) para += 0b10;
                if ((flag2 == "-r" || flag2 == "--rank") && !(para & 0b100)) para += 0b100;
            }
            compare(para);
        } else if (flag == "--eval") {
            int runCount = 1;
            if (argc >= 3 && isValidUnNum(charToStr(argv[2])))
                runCount = stringToUnNum(charToStr(argv[2]));

            string tmpOtpDir = "/tmp/ASR";
            if (dirExist(tmpOtpDir)) rmFile(strToChar(tmpOtpDir + "/*"));
            else mkdir(tmpOtpDir);
            printf("Executing... Total run: %d", runCount);
            fflush(stdout);
            for (int i = 0; i < runCount; i++) {
                compare(0b1000);
                printf("\33[2K\r%d/%d Execution finished (%5.2f%%)", i + 1, runCount, (i + 1) * 100 / (float)runCount);
                fflush(stdout);
            } printf("\33[2K\rFinalizing...");
            fflush(stdout);

            const string home = (getenv("HOME") ? getenv("HOME") : ".");
            if (!dirExist(home + "/ASR")) mkdir(home + "/ASR");
            string subID = genID("AR");
            mv("/tmp/ASR", home + "/ASR/" + subID);
            writeFile("#!/usr/bin/env bash\ncd " + home + "/ASR/" + subID + "\npython3 gen.py", "./tmpRun");
            writeFile(genEvalPY(), home + "/ASR/" + subID + "/gen.py");
            runShell("chmod +x ./tmpRun");
            runShell("./tmpRun");
            rmFile("./tmpRun");
            rmFile(strToChar(home + "/ASR/" + subID + "/gen.py"));
            printf("\33[2K\r%d runs done!\n", runCount);
            fflush(stdout);
        } else if (flag == "-u" || flag == "--update") {
            print(update(argc, argv));
        } else if (flag == "-r" || flag == "--remove") {
            if (argc < 3) print(illegalCmd(1, "remove"));
            else print(remove(argv[2]));
        } else if (flag == "-reset") {
            print("use --reset");
        } else if (flag == "--reset") {
            print(reset());
        } else if (flag == "--genTestCase") {
            genTestCase(argc, argv);
        } else print("Flag not defined, use -h for help.");
    }
    return 0;
}

