#!/usr/bin/env bash
rm -rf ./a.out
gcc -c -Wall -Werror coreObj/objOld.c
g++ -Wall -std=c++14 -Werror -pthread -g objOld.o util.cpp coreObj/objService.cpp coreObj/status.cpp coreObj/statusMap.cpp coreObj/confMap.cpp coreObj/cluster.cpp coreObj/algorithmObj.cpp coreObj/request.cpp coreObj/analyzer.cpp coreObj/comparator.cpp coreObj/bruteForce.cpp service/att.cpp service/aot.cpp assistant.cpp simulator.cpp main.cpp
rm -rf *.o
