//
// Created by Tongxuan on 2019-07-16.
//

#ifndef SCHEDULER_SERVICEOBJECT_H
#define SCHEDULER_SERVICEOBJECT_H

#include "object.h"

TF *stdTF;

int * sortCore(int *i, int length, int start, int end);

Request * requestList2Arr(RequestList *rl);
RequestList * requestArr2List(Request *r, int length);

Status * statusList2Arr(StatusList *sl);
StatusList * statusArr2List(Status *s, int length);

MapNode * statusMap2Arr(StatusMap *sm);
StatusMap * mapNodeArr2Map(MapNode *mn, int length);

RequestList * sortPrio(RequestList *rl);
RequestList * sortAdjPrio(RequestList *rl);
RequestList * sortPu(RequestList *rl);
RequestList * sortExeLength(RequestList *rl);
RequestList * sortExeSeq(RequestList *rl);
RequestList * sortExeTimeStamp(RequestList *rl);

StatusList * sortStartTime(StatusList *sl);
StatusList * sortFinTime(StatusList *sl);

StatusMap * sortTimeNode(StatusMap *sm);

StatusMap * updateStatusMap(StatusMap *sm, Status *s);

void setSTDTF(TF *);
void deleteSTDTF();

#endif //SCHEDULER_SERVICEOBJECT_H
