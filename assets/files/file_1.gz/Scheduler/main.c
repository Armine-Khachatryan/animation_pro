//
// Created by Tongxuan on 2019-07-12.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"
#include "serviceScheduler.h"
#include "main.h"
#include "serviceObject.h"

unsigned int mode = 0;

int runCore(RequestList *rl, Cluster *c, Scheduler *s) {
    addJob(c, rl, s);
    deleteSTDTF();
    if (mode == 0) printRequestListSimu(s->sortedJobList);
    if (mode == 1) printRequestList(s->sortedJobList);
    return 0;
}

int main(int argv, char **argc) {
    if (argv < 2) {
        printf("No target\n");
        return 1;
    } if (argv > 2) {
        if (strcmp(argc[2], "-t") == 0 || strcmp(argc[2], "--test") == 0) mode = 1;
    }

    Initializer *rtn = init(argc[1]);

    if (rtn == NULL) return 2;
    RequestList *rl = copyRequestList(rtn->rl);
    Cluster *cl = copyCluster(rtn->cl);
    Scheduler *s = copyScheduler(rtn->s);
    deleteInit(rtn);
    rtn = NULL;

    runCore(rl, cl, s);
    deleteRequestList(rl);
    deleteCluster(cl);
    deleteScheduler(s);
    rl = NULL;
    cl = NULL;
    s = NULL;
    return 0;
}