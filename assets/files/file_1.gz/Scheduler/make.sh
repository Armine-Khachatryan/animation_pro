#!/usr/bin/env bash
#gcc -fPIC -Wall -Werror -g object.c serviceObject.c util.c serviceScheduler.c main.c
gcc -fPIC -Wall -Werror -g object.c serviceObject.c util.c serviceScheduler.c main.c
rm -rf *.gch *.o
