//
// Created by Tongxuan on 2019-07-16.
//

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

#include "serviceScheduler.h"
#include "serviceObject.h"
#include "util.h"

bool requestValidator(Cluster *c, Request *r) {
    if (r->exeLength <= 0) return false;
    for (unsigned int i = 0; i < c->t->len; i++) if (r->t->p[i]->var > c->t->p[i]->var) return false;
    return true;
}

VJL *newVJL(unsigned int t, RequestList *rl) {
    VJL *rtn = malloc(sizeof(VJL));
    rtn->ct = t;
    rtn->rl = copyRequestList(rl);
    return rtn;
}

VJL *copyVJL(VJL *v) {
    if (v == NULL) return newVJL(0, newRequestList());
    return newVJL(v->ct, v->rl);
}

VJL *moveVJL(VJL *v) {
    VJL *rtn = copyVJL(v);
    deleteVJL(v);
    v = NULL;
    return rtn;
}

void deleteVJL(VJL *v) {
    if (v == NULL) return;
    v->ct = 0;
    deleteRequestList(v->rl);
    v->rl = NULL;
    free(v);
    v = NULL;
}

VJL *getValidJobList(RequestList *rtn, RequestList *rl, StatusMap *sm, int ct) {
    RequestList *tmpPushSort = sortPu(rl);
    if (sm->length == 0) ct = tmpPushSort->head->r->pushTime;
    else
        for (MapConnector *mc = sm->head; mc != NULL; mc = mc->next)
            if (mc->n->time > ct) {
                ct = mc->n->time;
                break;
            }
    deleteRequestList(tmpPushSort);
    for (RequestNode *rn = rl->head; rn != NULL; rn = rn->next)
        if (rn->r->pushTime <= ct)
            requestListInsert(rtn, rn->r);
    VJL *rtnVJL = malloc(sizeof(VJL));
    rtnVJL->rl = moveRequestList(sortAdjPrio(rtn));
    rtnVJL->ct = ct;
    return rtnVJL;
}

void restoreSchedulerSettings(Scheduler *s) {
    for (RequestNode *temp = s->jobList->head; temp != NULL; temp = temp->next) {
        temp->r->adjPrio = temp->r->prio;
        temp->r->exeSeq = 0xFFFF;
        temp->r->exeTimeStamp = 0xFFFF;
    }
}

void addJob(Cluster *c, RequestList *rl, Scheduler *s) {
    for (RequestNode *rn = rl->head; rn != NULL; rn = rn->next)
        if (requestValidator(c, rn->r)) requestListInsert(s->jobList, rn->r);
    RequestList *tmp = moveRequestList(sortPu(s->jobList));
    RequestList *tmp2 = moveRequestList(sortPrio(tmp));
    deleteRequestList(tmp);
    deleteRequestList(s->jobList);
    s->jobList = moveRequestList(tmp2);

    unsigned int baseTime = 0;
    unsigned int currTime = 0;

    int testCount = 0;
    while (s->jobList->length != 0) {
        updateAdjPrio(s->jobList, 0.125, s);
        RequestList *eliRL = newRequestList();
        VJL *rtnV = getValidJobList(eliRL, s->jobList, s->sttMap, currTime);
        deleteRequestList(eliRL);
        eliRL = copyRequestList(rtnV->rl);
        currTime = rtnV->ct;
        deleteVJL(rtnV);
        if (eliRL->length == 0) {
            currTime++;
            deleteRequestList(eliRL);
            continue;
        }

        StatusMap *internalSM = copyStatusMap(s->sttMap);
        for (RequestNode *rn = eliRL->head; rn != NULL; rn = rn->next) {
            setFirstPosition(c, internalSM, rn->r);
            Status *tmpS = newStatus(rn->r->exeTimeStamp, rn->r->exeTimeStamp + rn->r->exeLength,
                                     rn->r->t->len, rn->r->t->p);
            internalSM = moveStatusMap(updateStatusMap(internalSM, tmpS));
            deleteStatus(tmpS);
        }
        RequestList *tmpRL = sortExeTimeStamp(eliRL);
        deleteRequestList(eliRL);
        eliRL = moveRequestList(tmpRL);
        int exeTime = eliRL->head->r->exeTimeStamp;
        baseTime = eliRL->head->r->exeTimeStamp + eliRL->head->r->exeLength;

        for (RequestNode *rn = eliRL->head; rn != NULL; rn = rn->next) {
            if (rn->r->exeTimeStamp != exeTime) break;
            if (eliRL->head->r->exeTimeStamp + eliRL->head->r->exeLength < baseTime)
                baseTime = eliRL->head->r->exeTimeStamp + eliRL->head->r->exeLength;
            Status *tmpST = newStatus(rn->r->exeTimeStamp, rn->r->exeTimeStamp + rn->r->exeLength,
                                    rn->r->t->len, rn->r->t->p);
            s->sttMap = moveStatusMap(updateStatusMap(s->sttMap, tmpST));
            deleteStatus(tmpST);
            s->expExeTime = (0.85 * s->sortedJobList->length + 0.15 * rn->r->exeLength);
            requestListInsert(s->sortedJobList, rn->r);
            requestListDeleteEleReq(s->jobList, rn->r);
        }

        deleteRequestList(eliRL);
        deleteStatusMap(internalSM);

        for (RequestNode *rn = s->jobList->head; rn != NULL; rn = rn->next) {
            if (baseTime > rn->r->pushTime) rn->r->totalWaitTime = baseTime - rn->r->pushTime;
            else rn->r->totalWaitTime = 0;
        }
        restoreSchedulerSettings(s);
        testCount++;
        if (testCount > 0xFF) break;
    }
}

float calAdjPrio(Request *r, float alpha, float exp) {
    float rtn = r->prio;
    if (r->totalWaitTime > r->prio * exp) rtn -= (alpha / 10) * r->totalWaitTime;
    return rtn;
}

void updateAdjPrio(RequestList *rl, float alpha, Scheduler *s) {
    for (RequestNode *rn = rl->head; rn != NULL; rn = rn->next)
        rn->r->adjPrio = calAdjPrio(rn->r, alpha, s->expExeTime);
}

bool validatePosition(Cluster *c, MapConnector *mc, unsigned int position, Request *r) {
    MapConnector *temp = mc;
    unsigned int finTime = temp->n->time + r->exeLength;
    if (r->pushTime > temp->n->time) return false;
    temp = temp->next;
    while (temp != NULL) {
        if (r->pushTime > temp->n->time) return false;
        if (r->t->p[position]->var > (c->t->p[position]->var - temp->n->t->p[position]->var)) return false;

        if (temp->n->time >= finTime) return true;
        temp = temp->next;
    }
    return true;
}

bool veriAllPara(Cluster *c, MapConnector *mc, Request *r) {
    for (unsigned int i = 0; i < c->t->len; i++) if (!(validatePosition(c, mc, i, r))) return false;
    return true;
}

void setFirstPosition(Cluster *c, StatusMap *sm, Request *r) {
    int rtn = 0;
    MapConnector *mc = sm->head;
    while (mc != NULL) {
        if (veriAllPara(c, mc, r)) {
            r->exeTimeStamp = mc->n->time;
            r->exeSeq = rtn;
            return;
        }
        mc = mc->next; rtn++;
    }
    if (sm->length == 0) {
        r->exeTimeStamp = r->pushTime;
        r->exeSeq = 0;
        return;
    }
    r->exeTimeStamp = sm->tail->n->time;
    r->exeSeq = rtn;
}

