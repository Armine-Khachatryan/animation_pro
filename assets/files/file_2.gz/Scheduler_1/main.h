//
// Created by Tongxuan on 2019-07-18.
//

#ifndef SCHEDULER_MAIN_H
#define SCHEDULER_MAIN_H

#include "object.h"

int runCore(RequestList *, Cluster *, Scheduler *);

#endif //SCHEDULER_MAIN_H
