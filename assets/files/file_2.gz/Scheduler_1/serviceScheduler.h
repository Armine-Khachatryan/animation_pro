//
// Created by Tongxuan on 2019-07-16.
//

#ifndef SCHEDULER_OBJECTSCHEDULER_H
#define SCHEDULER_OBJECTSCHEDULER_H

#include "object.h"

struct validJobList {
    RequestList *rl;
    unsigned int ct;
};

typedef struct validJobList VJL;

VJL * newVJL();
VJL * copyVJL(VJL *);
VJL * moveVJP(VJL *);
void deleteVJL(VJL *);

void addJob(Cluster *c, RequestList *rl, Scheduler *s);
void setFirstPosition(Cluster *c, StatusMap *sm, Request *r);

void updateAdjPrio(RequestList *rl, float alpha, Scheduler *s);
void syncSortedJobToSttList(Scheduler *s);
void calOverallUtility(Scheduler *s, Cluster *cl);

#endif //SCHEDULER_OBJECTSCHEDULER_H
