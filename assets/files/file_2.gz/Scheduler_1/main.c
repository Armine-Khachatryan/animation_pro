//
// Created by Tongxuan on 2019-07-12.
//

#include <stdlib.h>
#include <stdio.h>

#include "util.h"
#include "serviceScheduler.h"
#include "main.h"
#include "serviceObject.h"

int runCore(RequestList *rl, Cluster *c, Scheduler *s) {
    addJob(c, rl, s);
    deleteSTDTF();
    printRequestListSimu(s->sortedJobList);
    return 0;
}

int main(int argv, char **argc) {
    if (argv < 2) {
        printf("No target\n");
        return 1;
    }

    Initializer *rtn = init(argc[1]);

    if (rtn == NULL) return 2;
    RequestList *rl = copyRequestList(rtn->rl);
    Cluster *cl = copyCluster(rtn->cl);
    Scheduler *s = copyScheduler(rtn->s);
    deleteInit(rtn);
    rtn = NULL;

    runCore(rl, cl, s);
    deleteRequestList(rl);
    deleteCluster(cl);
    deleteScheduler(s);
    rl = NULL;
    cl = NULL;
    s = NULL;
    return 0;
}