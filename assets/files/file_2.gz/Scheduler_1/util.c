//
// Created by Tongxuan on 2019-07-18.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"
#include "serviceObject.h"

char *readFile(char *file) {
    if (file == NULL || *file == *("")) return NULL;

    FILE *fp = fopen(file, "r");
    if (fp == NULL) return NULL;

    char *rtn = calloc(0xFFFF, sizeof(char));
    char *ch = calloc(2048, sizeof(char));
    *ch = fgetc(fp);
    while (*ch != EOF) {
        strcat(rtn, ch);
        *ch = fgetc(fp);
    }
    fclose(fp);
    free(ch);
    return rtn;
}

Initializer *init(char *file) {
    char *fileRes = readFile(file);
    if (fileRes == NULL) {
        printf("No such file\n");
        return NULL;
    }
    StrVec *line = split(fileRes, "\n");
    free(fileRes);
    if (!validateInput(line)) {
        deleteStrVec(line);
        printf("Invalid syntax\n");
        return NULL;
    }

    StrVec *plistConf = split(line->argc[0], " ");
    StrVec *clusterConf = split(line->argc[1], " ");
    Initializer *rtn = malloc(sizeof(Initializer));

    plist tmpCl = newPlist(plistConf->length);
    for (unsigned int i = 0; i < plistConf->length; i++)
        tmpCl[i] = newPara(plistConf->argc[i], strToInt(clusterConf->argc[i]));
    TF *std = newTF(plistConf->length, tmpCl);
    setSTDTF(std);
    deleteTF(std);

    rtn->s = newScheduler();
    rtn->rl = newRequestList();
    rtn->cl = newCluster(plistConf->length, tmpCl);
    deleteStrVec(clusterConf);
    deletePlist(plistConf->length, tmpCl);

    for (int i = 2; i < line->length; i++) {
        char **tmpStrArr = line->argc;
        StrVec *reqConf = split(tmpStrArr[i], " ");
        //Required WITHOUT label: RID, PushT, Prio, ExeLength
        plist reqPlist = newPlist(plistConf->length);
        for (unsigned int j = 0; j < plistConf->length; j++)
            reqPlist[j] = newPara(plistConf->argc[j], strToInt(reqConf->argc[4 + j]));
        Request *tmp = newRequest(reqConf->argc[0], strToInt(reqConf->argc[1]), strToInt(reqConf->argc[2]),
                                  strToInt(reqConf->argc[3]),plistConf->length, reqPlist);
        deletePlist(plistConf->length, reqPlist);
        requestListInsert(rtn->rl, tmp);
        deleteRequest(tmp);
        deleteStrVec(reqConf);
    }
    deleteStrVec(plistConf);
    deleteStrVec(line);
    return rtn;
}

StrVec *split(char *tar, char *separator) {
    char *resCpy = calloc(0xFFFF, sizeof(char));
    strcpy(resCpy, tar);
    char **str = calloc(IPT_LEN_MAX, sizeof(char *));
    int count = 0;
    char *cptr = strtok(resCpy, separator);
    while (cptr != NULL) {
        str[count] = cptr;
        cptr = strtok(NULL, separator);
        count++;
    }
    StrVec *rtn = newStrVec(count, str);
    for (unsigned int i = 0; i < count; i++) {
        str[i] = NULL;
    }
    free(str);
    free(resCpy);
    str = NULL;
    resCpy = NULL;
    return rtn;
}

bool validateInput(StrVec *input) {
    if (input == NULL || input->length < 3) return false;

    StrVec *header = split(input->argc[0], " ");
    if (header->length < 1) {
        deleteStrVec(header);
        return false;
    }

    StrVec *tmp = split(input->argc[1], " ");
    if (tmp->length < header->length) goto falseCase;

    for (int j = 0; j < header->length; j++)
        if (strspn(tmp->argc[j], "0123456789") != strlen(tmp->argc[j])) goto falseCase;
    deleteStrVec(tmp);

    for (int i = 2; i < input->length; i++) {
        tmp = split(input->argc[i], " ");
        //Required WITHOUT label: RID, PushT, Prio, ExeLength
        unsigned int minReqLen = 4 + header->length;
        if (tmp->length < minReqLen) goto falseCase;
        for (int j = 1; j < minReqLen; j++)
            if (strspn(tmp->argc[j], "0123456789") != strlen(tmp->argc[j])) goto falseCase;
        deleteStrVec(tmp);
    }
    deleteStrVec(header);
    return true;

    falseCase:
    deleteStrVec(tmp);
    deleteStrVec(header);
    return false;
}

int strToInt(char *str) {
    char *ptr;
    return (int) strtol(str, &ptr, 10);
}

void printBool(bool b) {
    printf("%s\n", b ? "True" : "False");
}

