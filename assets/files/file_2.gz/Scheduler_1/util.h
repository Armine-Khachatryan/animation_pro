//
// Created by Tongxuan on 2019-07-18.
//

#ifndef SCHEDULER_UTIL_H
#define SCHEDULER_UTIL_H

#include <stdbool.h>

#include "object.h"

char * readFile(char *);
StrVec *split(char *, char *);
bool validateInput(StrVec *);
int strToInt(char *);
Initializer *init(char *);

void printBool(bool);

#endif //SCHEDULER_UTIL_H

